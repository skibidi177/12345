# HDT STORE BOT

Discord bot bán hàng Digital/MMO (YouTube Premium, CapCut Pro, Discord Nitro, v.v.) với hệ thống Ticket, Order, VietQR Payment, bàn giao tài khoản bảo mật, và thống kê.

## Giao diện & hiệu ứng (bản cập nhật)

- Toàn bộ embed dùng chung một "theme": footer có slogan, viền màu theo ngữ cảnh (mặc định / thành công / lỗi / cảnh báo / premium cho hạng Diamond & Owner menu), bố cục dùng field thay vì liệt kê dòng phẳng.
- Có thể cấu hình `STORE_TAGLINE`, `STORE_BANNER_URL`, `STORE_THUMBNAIL_URL` trong `.env` để gắn logo/banner riêng của bạn — không bắt buộc, bỏ trống vẫn chạy bình thường.
- "Animation" trong Discord không thể làm chuyển động thật một embed, nên bot dùng đúng kỹ thuật các app lớn hay dùng: gửi/sửa lại tin nhắn liên tiếp để tạo hiệu ứng loading — áp dụng cho lúc mở `/shop`, tạo ticket, tạo mã VietQR (`/vietqrcreate`, `/deposit`), và đặc biệt là lúc đối soát thanh toán (`Kiểm tra thanh toán`, và luồng `/qrdone` có hẳn một tin nhắn trạng thái với thanh tiến độ cập nhật theo từng lần kiểm tra thay vì im lặng chờ).
- Đã hạn chế tối đa icon/emoji theo đúng tinh thần "Dark MMO Store chuyên nghiệp" — trạng thái còn/hết hàng, bật/tắt sản phẩm... đều dùng chữ in đậm thay vì icon màu.

## Phạm vi đã triển khai trong bản này

Đã có code thật, chạy được, theo đúng kiến trúc `src/commands|events|buttons|modals|selectMenus|models|services|utils|config`:

- Shop (danh mục → sản phẩm → mua ngay), Product Manager (`/product`)
- Order system với Order ID `HDT-YYYY-000001`, trạng thái đầy đủ
- Ticket system (claim / add / remove / close + transcript, phân quyền)
- `/guiacc` — bàn giao tài khoản bảo mật (mã hoá AES-256-GCM, không log/không public)
- VietQR: `/vietqrcreate`, `/qrdone`, `/payment`, webhook `/webhooks/vietqr`, đối soát amount + nội dung + destination + chống trùng transaction
- Currency format `k/tr` theo đúng quy tắc
- `/balance`, `/deposit`, `/profile`, `/history`, `/order`, `/staff`, `/owner`, `/stats`
- Welcome + auto-role, log channels, admin log & security log, error handling không crash bot

**Chưa triển khai trong bản đầu này** (kiến trúc đã chừa sẵn chỗ, có thể bổ sung sau): Coupon/Discount, Review sau khi hoàn thành đơn (DM), Referral/Affiliate, `/warranty` riêng (dữ liệu bảo hành đã được lưu trên Order), `/announce`. Nói mình biết nếu bạn muốn triển khai tiếp phần nào.

---

## 1. Tạo Discord Bot

1. Vào https://discord.com/developers/applications → **New Application**.
2. Vào tab **Bot** → **Add Bot**.
3. Bật **Message Content Intent** và **Server Members Intent** (Privileged Gateway Intents).

## 2. Lấy Token

- Trong tab **Bot**, bấm **Reset Token** → copy token → dán vào `DISCORD_TOKEN` trong `.env`.
- Vào tab **OAuth2 → General**, copy **Application ID** → dán vào `CLIENT_ID`.
- Vào tab **OAuth2 → URL Generator**, chọn scope `bot` + `applications.commands`, chọn quyền cần thiết (Manage Channels, Manage Roles, Send Messages, Embed Links, Attach Files, Read Message History) → dùng link tạo ra để mời bot vào server.

## 3. Tạo MongoDB

- Cách nhanh nhất: tạo cluster miễn phí tại https://www.mongodb.com/cloud/atlas
- Lấy connection string dạng `mongodb+srv://user:pass@cluster.../hdt-store` → dán vào `MONGODB_URI`.
- Hoặc chạy MongoDB local: `mongodb://localhost:27017/hdt-store`.

## 4. Cấu hình `.env`

```bash
cp .env.example .env
```

Điền đầy đủ: `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`, `OWNER_ID`, `MONGODB_URI`, các role ID, các channel log ID, `TICKET_CATEGORY_ID`, và toàn bộ phần VietQR (`VIETQR_CLIENT_ID`, `VIETQR_API_KEY` lấy tại https://my.vietqr.io, thông tin ngân hàng, `ENCRYPTION_KEY` (chuỗi ngẫu nhiên 32+ ký tự), `WEBHOOK_SECRET`.

## 5. Deploy slash command

```bash
npm install
npm run deploy
```

Lệnh này đăng ký toàn bộ slash command lên server (`GUILD_ID`) — cập nhật gần như ngay lập tức.

## 6. Chạy bot local

```bash
npm start
```

## 7. Chạy bot trên VPS Ubuntu

```bash
sudo apt update && sudo apt install -y nodejs npm
git clone <repo-của-bạn> hdt-store-bot && cd hdt-store-bot
npm install
cp .env.example .env   # rồi chỉnh sửa
npm run deploy
npm start
```

Nếu dùng webhook thanh toán, mở port `WEBHOOK_PORT` (mặc định 3001) trên firewall/VPS, hoặc đặt sau reverse proxy (Nginx) với HTTPS.

## 8. Dùng PM2 để bot tự chạy lại

```bash
npm install -g pm2
pm2 start src/index.js --name hdt-store-bot
pm2 save
pm2 startup   # làm theo hướng dẫn để PM2 tự khởi động cùng VPS
```

Xem log: `pm2 logs hdt-store-bot`. Khởi động lại sau khi sửa code: `pm2 restart hdt-store-bot`.

## 9. Danh sách slash command

| Command | Quyền | Mô tả |
|---|---|---|
| `/shop` | Ai cũng dùng được | Mở giao diện cửa hàng |
| `/order <order_id>` | Chủ đơn / Staff | Xem chi tiết đơn hàng |
| `/ticket` | Ai cũng dùng được | Mở bảng tạo ticket |
| `/qrdone` | Khách trong ticket | Báo đã chuyển khoản |
| `/balance` | Ai cũng dùng được | Xem số dư |
| `/deposit <amount>` | Ai cũng dùng được | Tạo QR nạp tiền |
| `/profile` | Ai cũng dùng được | Xem hồ sơ khách hàng |
| `/history` | Ai cũng dùng được | Lịch sử đơn hàng |
| `/vietqrcreate <amount>` | Payment Staff, trong ticket | Tạo QR thanh toán cho đơn |
| `/payment info\|cancel\|check\|list\|search` | Payment Staff | Quản lý payment request |
| `/staff orders` | Staff | Dashboard đơn hàng |
| `/product add\|remove\|edit\|price\|stock\|toggle\|list` | Owner/Admin | Quản lý sản phẩm |
| `/guiacc` | **Chỉ OWNER** | Bàn giao tài khoản bảo mật |
| `/stats` | Owner/Admin | Thống kê doanh thu |
| `/owner` | **Chỉ OWNER** | Menu quản trị |

## 10. Hướng dẫn thêm sản phẩm mới

```
/product add product_id:capcut-first-1m category:CapCut Pro name:Lần đầu - 1 tháng price:37000 package_label:1 tháng stock:50 warranty_days:30
```

Sau đó khách sẽ thấy sản phẩm ngay trong `/shop` → Mua hàng → chọn danh mục "CapCut Pro".

Để đổi giá nhanh: `/product price product_id:capcut-first-1m price:39000`
Để bật/tắt bán: `/product toggle product_id:capcut-first-1m`

---

## Ghi chú bảo mật quan trọng

- Mật khẩu tài khoản (`/guiacc`) được mã hoá AES-256-GCM bằng `ENCRYPTION_KEY`, không bao giờ log ra console, không gửi lên channel public, và bị xoá khỏi database ngay khi bấm "Đã xử lý".
- Không bao giờ đánh dấu đơn hàng `PAID` chỉ vì khách nói đã chuyển, gửi bill, hay bấm `/qrdone` — hệ thống chỉ xác nhận khi có giao dịch thật khớp cả số tiền, nội dung chuyển khoản, tài khoản nhận, và chưa từng được dùng trước đó (`paymentVerificationService.js`).
- Toàn bộ secret (token, API key, thông tin ngân hàng) nằm trong `.env`, không hard-code trong source.

## Prefix commands (`-`)

The bot also supports message commands using the `-` prefix. Enable the **Message Content Intent** for the bot in the Discord Developer Portal. Examples:

- `-help` — command list
- `-hdtmenu` or `-hdtshop` — open the HDT STORE menu
- `-balance`, `-profile`, `-history`
- `-deposit 99000`
- `-order ORDER_ID`
- `-ticket`
- `-vietqrcreate 99000` (staff, inside a ticket)
- `-product list` / `-product price product-id 99000` (admin)
- `-payment list` (staff)
- `-hdttext "HDT STORE"`, `-hdtdecor "Feedback"`, `-hdtemoji`

Prefix messages cannot be ephemeral. Commands that must open a Discord modal (currently `qrdone` and `guiacc`) direct users to the existing interactive panel/slash interaction instead. Existing slash commands remain available for compatibility. The Shop landing view now uses one select menu for navigation; product browsing continues through category and product select menus.
