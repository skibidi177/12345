// deploy-commands.js
// Registers all slash commands to the configured guild (fast propagation,
// recommended during development / for a single-server store bot).
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('./src/config/config');

function collectCommandData(dir) {
  const commands = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      commands.push(...collectCommandData(fullPath));
    } else if (entry.name.endsWith('.js')) {
      const command = require(fullPath);
      if (command?.data) commands.push(command.data.toJSON());
    }
  }
  return commands;
}

async function main() {
  const commands = collectCommandData(path.join(__dirname, 'src', 'commands'));
  const rest = new REST({ version: '10' }).setToken(config.discord.token);

  console.log(`Đang đăng ký ${commands.length} slash command(s)...`);
  await rest.put(Routes.applicationGuildCommands(config.discord.clientId, config.discord.guildId), { body: commands });
  console.log('Đăng ký thành công.');
}

main().catch((err) => {
  console.error('Deploy thất bại:', err);
  process.exit(1);
});
