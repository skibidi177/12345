// src/selectMenus/shopMenu.js
const { ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const productService = require('../services/productService');
const { storeEmbed, errorEmbed, DIVIDER } = require('../utils/embeds');
const { formatVND } = require('../utils/currency');
const config = require('../config/config');

async function buildCategorySelect() {
  const categories = await productService.listCategories();
  if (!categories.length) return null;

  const menu = new StringSelectMenuBuilder()
    .setCustomId('select_category')
    .setPlaceholder('Chọn danh mục sản phẩm')
    .addOptions(categories.slice(0, 25).map((c) => ({ label: c, value: c })));

  return new ActionRowBuilder().addComponents(menu);
}

async function buildProductSelect(category) {
  const products = await productService.listProducts(category);
  if (!products.length) return null;

  const menu = new StringSelectMenuBuilder()
    .setCustomId('select_product')
    .setPlaceholder('Chọn gói sản phẩm')
    .addOptions(
      products.slice(0, 25).map((p) => ({
        label: `${p.name}${p.packageLabel ? ' - ' + p.packageLabel : ''}`.slice(0, 100),
        description: `${formatVND(p.price)} — ${p.stock > 0 ? `còn ${p.stock}` : 'hết hàng'}`.slice(0, 100),
        value: p.productId,
      }))
    );

  return new ActionRowBuilder().addComponents(menu);
}

async function handleCategorySelect(interaction) {
  const category = interaction.values[0];
  const row = await buildProductSelect(category);
  if (!row) {
    return interaction.update({ embeds: [errorEmbed('NO_PRODUCTS', 'Danh mục này hiện chưa có sản phẩm.')], components: [] });
  }
  await interaction.update({
    embeds: [storeEmbed(category, `Đây là các gói đang mở bán trong danh mục **${category}**. Chọn một gói bên dưới để xem chi tiết.`)],
    components: [row],
  });
}

async function handleProductSelect(interaction) {
  const productId = interaction.values[0];
  const product = await productService.getProduct(productId);
  if (!product || !product.active) {
    return interaction.update({ embeds: [errorEmbed('PRODUCT_UNAVAILABLE', 'Sản phẩm này hiện không khả dụng.')], components: [] });
  }

  const inStock = product.stock > 0;
  const embed = storeEmbed(
    `${product.category} — ${product.name}`,
    [
      product.description || `Gói ${product.name} thuộc danh mục ${product.category}, được ${config.store.name} chuẩn bị và kiểm tra kỹ trước khi bàn giao.`,
      DIVIDER,
    ].join('\n')
  ).addFields(
    { name: 'Gói', value: product.packageLabel || '—', inline: true },
    { name: 'Giá', value: `**${formatVND(product.price)}**`, inline: true },
    { name: 'Tình trạng', value: inStock ? `**CÒN HÀNG** (${product.stock})` : '**HẾT HÀNG**', inline: true },
    { name: 'Đã bán', value: `${product.sold}`, inline: true },
    { name: 'Bảo hành', value: `${product.warrantyDays} ngày`, inline: true }
  );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`buy_now:${product.productId}`).setLabel('Mua ngay').setStyle(ButtonStyle.Success).setDisabled(!inStock)
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

module.exports = { buildCategorySelect, buildProductSelect, handleCategorySelect, handleProductSelect };
