// src/models/Product.js
const { Schema, model } = require('mongoose');

const ProductSchema = new Schema(
  {
    productId: { type: String, required: true, unique: true, index: true }, // slug, e.g. youtube-personal
    category: { type: String, required: true }, // e.g. "YouTube Premium"
    name: { type: String, required: true }, // display name, e.g. "Cá nhân"
    packageLabel: { type: String, default: '' }, // e.g. "1 tháng"
    price: { type: Number, required: true }, // raw VND integer
    description: { type: String, default: '' },
    stock: { type: Number, default: 0 },
    sold: { type: Number, default: 0 },
    active: { type: Boolean, default: true },
    warrantyDays: { type: Number, default: 30 },
  },
  { timestamps: true }
);

module.exports = model('Product', ProductSchema);
