// src/models/User.js
const { Schema, model } = require('mongoose');

const UserSchema = new Schema(
  {
    discordId: { type: String, required: true, unique: true, index: true },
    balance: { type: Number, default: 0 },
    totalDeposited: { type: Number, default: 0 },
    totalSpent: { type: Number, default: 0 },
    totalOrders: { type: Number, default: 0 },
    completedOrders: { type: Number, default: 0 },
    referralCode: { type: String, unique: true, sparse: true },
    referredBy: { type: String, default: null },
    joinedStoreAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = model('User', UserSchema);
