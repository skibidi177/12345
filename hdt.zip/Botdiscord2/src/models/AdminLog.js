// src/models/AdminLog.js
const { Schema, model } = require('mongoose');

const AdminLogSchema = new Schema(
  {
    action: { type: String, required: true },
    actorId: { type: String, required: true },
    targetId: { type: String, default: null },
    detail: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = model('AdminLog', AdminLogSchema);
