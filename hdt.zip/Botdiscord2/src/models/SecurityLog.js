// src/models/SecurityLog.js
const { Schema, model } = require('mongoose');

const SecurityLogSchema = new Schema(
  {
    event: { type: String, required: true },
    actorId: { type: String, required: true },
    detail: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = model('SecurityLog', SecurityLogSchema);
