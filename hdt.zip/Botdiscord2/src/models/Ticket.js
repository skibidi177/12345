// src/models/Ticket.js
const { Schema, model } = require('mongoose');

const TicketSchema = new Schema(
  {
    channelId: { type: String, required: true, unique: true, index: true },
    guildId: { type: String, required: true },
    type: {
      type: String,
      enum: ['MUA_HANG', 'HO_TRO', 'THANH_TOAN', 'BAO_HANH', 'KHAC'],
      default: 'KHAC',
    },
    userId: { type: String, required: true },
    claimedBy: { type: String, default: null },
    status: { type: String, enum: ['OPEN', 'CLOSED'], default: 'OPEN' },
    orderId: { type: String, default: null },
    closedBy: { type: String, default: null },
    closedAt: { type: Date, default: null },
    closeReason: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = model('Ticket', TicketSchema);
