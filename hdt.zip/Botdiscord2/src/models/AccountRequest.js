// src/models/AccountRequest.js
// Stores OWNER-submitted account delivery info. Password is encrypted at rest
// and only ever decrypted transiently for an authorized "reveal" action.
const { Schema, model } = require('mongoose');

const AccountRequestSchema = new Schema(
  {
    requestId: { type: String, required: true, unique: true, index: true },
    orderId: { type: String, default: null },
    ownerId: { type: String, required: true },
    productType: { type: String, required: true },
    account: { type: String, required: true }, // email / username - not treated as secret
    note: { type: String, default: '' },
    // Encrypted password payload (AES-256-GCM)
    passwordEnc: {
      iv: { type: String, default: null },
      authTag: { type: String, default: null },
      data: { type: String, default: null },
    },
    status: { type: String, enum: ['PENDING', 'DELIVERED', 'DELETED'], default: 'PENDING' },
    processedBy: { type: String, default: null },
    processedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = model('AccountRequest', AccountRequestSchema);
