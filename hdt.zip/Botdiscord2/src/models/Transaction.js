// src/models/Transaction.js
// Raw incoming bank transactions (from webhook / manual staff check)
const { Schema, model } = require('mongoose');

const TransactionSchema = new Schema(
  {
    reference: { type: String, required: true, unique: true, index: true },
    amount: { type: Number, required: true },
    description: { type: String, required: true },
    accountNumber: { type: String, default: null },
    transactionTime: { type: Date, required: true },
    used: { type: Boolean, default: false },
    usedByPaymentId: { type: String, default: null },
    rawPayload: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true }
);

module.exports = model('Transaction', TransactionSchema);
