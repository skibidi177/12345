// src/models/Order.js
const { Schema, model } = require('mongoose');

const ORDER_STATUSES = [
  'PENDING',
  'WAITING_PAYMENT',
  'PAID',
  'PROCESSING',
  'COMPLETED',
  'CANCELLED',
  'REFUNDED',
];

const OrderSchema = new Schema(
  {
    orderId: { type: String, required: true, unique: true, index: true },
    userId: { type: String, required: true, index: true },
    productId: { type: String, required: true },
    productName: { type: String, required: true },
    packageLabel: { type: String, default: '' },
    price: { type: Number, required: true },
    status: { type: String, enum: ORDER_STATUSES, default: 'PENDING' },
    staffId: { type: String, default: null },
    ticketId: { type: String, default: null },
    deliveryInfo: { type: String, default: null },
    warrantyDays: { type: Number, default: 30 },
    warrantyExpiresAt: { type: Date, default: null },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = model('Order', OrderSchema);
module.exports.ORDER_STATUSES = ORDER_STATUSES;
