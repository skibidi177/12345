// src/models/PaymentRequest.js
const { Schema, model } = require('mongoose');

const PaymentRequestSchema = new Schema(
  {
    paymentId: { type: String, required: true, unique: true, index: true },
    kind: { type: String, enum: ['ORDER', 'DEPOSIT'], default: 'ORDER' },
    orderId: { type: String, default: null },
    ticketId: { type: String, default: null },
    customerId: { type: String, required: true },
    createdBy: { type: String, required: true },
    amount: { type: Number, required: true },
    transferContent: { type: String, required: true, index: true },
    status: {
      type: String,
      enum: ['PENDING', 'PAID', 'EXPIRED', 'CANCELLED'],
      default: 'PENDING',
    },
    qrDataURL: { type: String, default: null },
    expiresAt: { type: Date, required: true },
    paidAt: { type: Date, default: null },
    transactionReference: { type: String, default: null },
    lastCheckedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = model('PaymentRequest', PaymentRequestSchema);
