// src/events/interactionCreate.js
// Central interaction router. Every branch is wrapped so a single failure
// can never crash the bot process (spec section 27).
const crypto = require('crypto');
const { errorEmbed } = require('../utils/embeds');
const { isPaymentStaff } = require('../utils/permissions');

const { handleShopButton } = require('../buttons/shopButtons');
const { handleTicketButton, handleTicketModal } = require('../buttons/ticketButtons');
const { handlePaymentButton } = require('../buttons/paymentButtons');
const { handleAccountButton } = require('../buttons/accountButtons');
const { handleCategorySelect, handleProductSelect } = require('../selectMenus/shopMenu');
const { handleGuiAccSubmit } = require('../modals/guiaccModal');
const { handleQrDoneSubmit } = require('../modals/qrdoneModal');
const paymentService = require('../services/paymentService');
const productService = require('../services/productService');
const statsService = require('../services/statsService');
const { formatVND } = require('../utils/currency');
const { storeEmbed } = require('../utils/embeds');

function errorCode() {
  return `ERR-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

async function safeReply(interaction, code, err) {
  console.error(`[INTERACTION][${code}]`, err);
  const payload = { embeds: [errorEmbed(code)], ephemeral: true };
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  } catch (_) {
    /* interaction likely expired - nothing more we can do */
  }
}

async function handleVqrRebuild(interaction) {
  const [action, value] = interaction.customId.split(':');
  if (!isPaymentStaff(interaction.member)) {
    return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền thao tác này.')], ephemeral: true });
  }
  const ticketService = require('../services/ticketService');
  const ticket = await ticketService.getTicketByChannel(interaction.channel.id);
  if (!ticket) return interaction.reply({ embeds: [errorEmbed('NOT_IN_TICKET', 'Không tìm thấy ticket.')], ephemeral: true });

  if (action === 'vqr_new') {
    const existing = await paymentService.getPendingForTicket(interaction.channel.id);
    if (existing) await paymentService.cancelPayment(existing.paymentId);
    const { createAndSendPayment } = require('../commands/staff/vietqrcreate');
    await interaction.update({ content: 'Đang tạo mã thanh toán mới...', embeds: [], components: [] });
    return createAndSendPayment(interaction, ticket, parseInt(value, 10));
  }
  if (action === 'vqr_keep') {
    return interaction.update({ content: `Đã giữ mã thanh toán cũ (\`${value}\`).`, embeds: [], components: [] });
  }
}

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        return await command.execute(interaction);
      }

      if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'shop_main_menu') {
          const action = interaction.values[0];
          const actionToButton = { buy: 'shop_buy', products: 'shop_products', deposit: 'shop_deposit', ticket: 'shop_ticket', history: 'shop_history', account: 'shop_account', guide: 'shop_guide' };
          const buttonId = actionToButton[action];
          if (!buttonId) return;
          // Reuse the existing action handlers while keeping the main Shop compact.
          return await handleShopButton(interaction, buttonId);
        }
        if (interaction.customId === 'select_category') return await handleCategorySelect(interaction);
        if (interaction.customId === 'select_product') return await handleProductSelect(interaction);
        return;
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'guiacc_modal') return await handleGuiAccSubmit(interaction);
        if (interaction.customId.startsWith('qrdone_modal:')) return await handleQrDoneSubmit(interaction);
        if (interaction.customId === 'ticket_add_modal' || interaction.customId === 'ticket_remove_modal') {
          return await handleTicketModal(interaction);
        }
        return;
      }

      if (interaction.isButton()) {
        const id = interaction.customId;

        if (id === 'prefix_modal_qrdone') {
          const command = interaction.client.commands.get('qrdone');
          if (command) return await command.execute(interaction);
        }
        if (id === 'prefix_modal_guiacc') {
          const command = interaction.client.commands.get('guiacc');
          if (command) return await command.execute(interaction);
        }
        if (id === 'owner_quick_stats') {
          const s = await statsService.overview();
          return interaction.reply({
            embeds: [storeEmbed('Quick Stats', `Hôm nay: **${formatVND(s.today.total)}**\nTháng này: **${formatVND(s.month.total)}**\nTổng: **${formatVND(s.allTime.total)}**`)],
            ephemeral: true,
          });
        }
        if (id === 'owner_quick_products') {
          const products = await productService.listProducts(null, { onlyActive: false });
          const lines = products.slice(0, 15).map((p) => `\`${p.productId}\` — ${formatVND(p.price)} — Stock: ${p.stock} — ${p.active ? '**BẬT**' : '**TẮT**'}`);
          return interaction.reply({ embeds: [storeEmbed('Sản phẩm', lines.join('\n') || '_Chưa có sản phẩm_')], ephemeral: true });
        }

        if (id.startsWith('vqr_new:') || id.startsWith('vqr_keep:')) return await handleVqrRebuild(interaction);
        if (id.startsWith('shop_') || id.startsWith('buy_now:')) return await handleShopButton(interaction);
        if (id.startsWith('ticket_')) return await handleTicketButton(interaction);
        if (id.startsWith('pay_')) return await handlePaymentButton(interaction);
        if (id.startsWith('acc_')) return await handleAccountButton(interaction);
        return;
      }
    } catch (err) {
      await safeReply(interaction, errorCode(), err);
    }
  },
};
