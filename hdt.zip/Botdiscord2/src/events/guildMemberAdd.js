// src/events/guildMemberAdd.js
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config');
const { storeEmbed, DIVIDER } = require('../utils/embeds');
const { ensureUser } = require('../services/orderService');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    await ensureUser(member.id).catch(() => null);

    if (config.roles.customer) {
      await member.roles.add(config.roles.customer).catch((err) => console.error('[AUTOROLE]', err.message));
    }

    if (!config.channels.welcome) return;
    const channel = await member.guild.channels.fetch(config.channels.welcome).catch(() => null);
    if (!channel) return;

    const embed = storeEmbed(
      `Chào mừng đến với ${config.store.name}`,
      [
        `Rất vui vì <@${member.id}> đã ghé thăm. Đây là nơi những giao dịch tài khoản số diễn ra nhanh gọn, minh bạch và được đội ngũ hỗ trợ đồng hành trong suốt quá trình — từ lúc chọn gói cho đến khi nhận hàng.`,
        DIVIDER,
        `Chỉ cần vài bước là bạn có thể bắt đầu: mở cửa hàng, chọn gói phù hợp, và để phần còn lại cho chúng tôi.`,
      ].join('\n\n'),
      { banner: true }
    ).addFields(
      { name: 'Thành viên thứ', value: `${member.guild.memberCount}`, inline: true },
      { name: 'Tham gia lúc', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('shop_buy').setLabel('SHOP').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('shop_ticket').setLabel('SUPPORT').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('shop_guide').setLabel('GUIDE').setStyle(ButtonStyle.Secondary)
    );
    await channel.send({ embeds: [embed], components: [row] }).catch(() => null);
  },
};
