// Prefix command router: supports the existing command modules with `-` commands.
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config');

const ALIASES = {
  hdtmenu: 'shop', hdtshop: 'shop', hdtproducts: 'shop', hdtbalance: 'balance',
  hdthistory: 'history', hdtprofile: 'profile', hdtdeposit: 'deposit',
  hdtorder: 'order', hdtticket: 'ticket', hdtqrdone: 'qrdone',
  hdtqr: 'vietqrcreate', hdtaddticket: 'ticket', hdtproduct: 'product',
  hdtstats: 'stats', hdtstaff: 'staff', hdtpayment: 'payment', hdtguiacc: 'guiacc',
};
const HELP = [
  '**HDT STORE — Prefix commands**',
  '`-hdtmenu` / `-hdtshop` — Mở cửa hàng',
  '`-balance` — Xem số dư', '`-deposit <số tiền>` — Nạp tiền',
  '`-profile` — Hồ sơ thành viên', '`-history` — Lịch sử đơn hàng',
  '`-order <mã đơn>` — Xem đơn hàng', '`-ticket` — Mở bảng ticket',
  '`-qrdone` — Báo đã chuyển khoản (mở modal qua nút/interaction nếu prefix không hỗ trợ)',
  '`-vietqrcreate <số tiền>` — Tạo QR trong ticket (Staff)',
  '`-product <add|remove|price|stock|toggle|list> ...` — Quản lý sản phẩm (Admin)',
  '`-payment <info|cancel|check|list|search> ...` — Quản lý thanh toán (Staff)',
  '`-staff orders` — Bảng điều khiển Staff', '`-stats` — Thống kê (Owner)',
  '`-hdttext <nội dung>` — Tạo kiểu chữ', '`-hdtdecor <nội dung>` — Trang trí chữ',
  '`-hdtemoji` — Xem bộ emoji gợi ý', '`-help` — Danh sách lệnh',
].join('\n');

function tokenize(input) {
  const out = [];
  const re = /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|(\S+)/g;
  let m;
  while ((m = re.exec(input)) !== null) out.push((m[1] ?? m[2] ?? m[3]).replace(/\\(["'\\])/g, '$1'));
  return out;
}
function styledText(input, style) {
  const maps = {
    bold: ['ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', '𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗'],
    italic: ['ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', '𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧'],
    gothic: ['ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', '𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷'],
  };
  const pair = maps[style] || maps.bold;
  const map = new Map([...pair[0]].map((ch, i) => [ch, [...pair[1]][i] || ch]));
  return [...input].map(ch => map.get(ch) || ch).join('');
}

function makeAdapter(message, command, args) {
  const schema = command.data?.toJSON?.() || {};
  let subcommand = null;
  let optionSchema = schema.options || [];
  if (optionSchema[0]?.type === 1 && args[0] && optionSchema.some(o => o.name === args[0].toLowerCase())) {
    subcommand = args.shift().toLowerCase();
    optionSchema = optionSchema.find(o => o.name === subcommand)?.options || [];
  }
  const values = {};
  let pos = 0;
  for (const opt of optionSchema) {
    if (opt.type === 1 || opt.type === 2) continue;
    const raw = args[pos++];
    if (raw === undefined) continue;
    if (opt.type === 4 || opt.type === 10) {
      const n = Number(raw); if (Number.isFinite(n)) values[opt.name] = n;
    } else if (opt.type === 5) values[opt.name] = ['true', 'yes', '1', 'on'].includes(raw.toLowerCase());
    else values[opt.name] = raw;
  }
  let lastMessage = null;
  const send = async (payload = {}) => {
    if (typeof payload === 'string') payload = { content: payload };
    const clean = { ...payload };
    delete clean.ephemeral; // Prefix messages cannot be ephemeral; replies are sent in-channel.
    lastMessage = await message.channel.send(clean);
    return lastMessage;
  };
  return {
    user: message.author, member: message.member, guild: message.guild, channel: message.channel,
    client: message.client, memberPermissions: message.memberPermissions,
    commandName: schema.name, isPrefixCommand: true,
    options: {
      getSubcommand: () => subcommand,
      getString: name => values[name] ?? null,
      getInteger: name => Number.isInteger(values[name]) ? values[name] : null,
      getNumber: name => typeof values[name] === 'number' ? values[name] : null,
      getBoolean: name => typeof values[name] === 'boolean' ? values[name] : null,
    },
    get deferred() { return Boolean(lastMessage); },
    get replied() { return Boolean(lastMessage); },
    async reply(payload) { return send(payload); },
    async followUp(payload) { return send(payload); },
    async deferReply() { if (!lastMessage) lastMessage = await message.channel.send({ content: '⏳ Đang xử lý yêu cầu...' }); return lastMessage; },
    async editReply(payload) {
      if (!lastMessage) return send(payload);
      const clean = typeof payload === 'string' ? { content: payload } : { ...payload };
      delete clean.ephemeral;
      return lastMessage.edit(clean);
    },
    async showModal() { return send({ content: 'ℹ️ Lệnh này cần Discord interaction để mở biểu mẫu. Hãy dùng nút tương ứng trên bảng HDT STORE.' }); },
  };
}

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (!message.guild || message.author.bot || !message.content.startsWith('-')) return;
    const raw = message.content.slice(1).trim();
    if (!raw) return;
    const tokens = tokenize(raw);
    const requested = (tokens.shift() || '').toLowerCase();
    if (requested === 'help' || requested === 'hdthelp' || requested === 'commands') {
      return message.reply({ embeds: [new EmbedBuilder().setColor(config.store.color).setTitle(`${config.store.name} — COMMANDS`).setDescription(HELP)] });
    }
    if (requested === 'hdttext' || requested === 'hdtdecor' || requested === 'hdtstyle') {
      const text = tokens.join(' ').trim();
      if (!text) return message.reply('Cách dùng: `-' + requested + ' <nội dung>` (có thể đặt nội dung trong dấu ngoặc kép).');
      const variants = [
        `𝐁𝐨𝐥𝐝: ${styledText(text, 'bold')}`,
        `𝑰𝒕𝒂𝒍𝒊𝒄: ${styledText(text, 'italic')}`,
        `𝔊𝔬𝔱𝔥𝔦𝔠: ${styledText(text, 'gothic')}`,
        `『 ${text} 』`, `𓆩 ${text} 𓆪`, `✦・${text}`,
      ];
      return message.reply({ embeds: [new EmbedBuilder().setColor(config.store.color).setTitle('HDT STORE | Text Studio').setDescription(variants.join('\n\n')).setFooter({ text: 'Unicode có thể hiển thị khác nhau tùy font và thiết bị.' })] });
    }
    if (requested === 'hdtemoji' || requested === 'hdtdecorlist') {
      return message.reply({ embeds: [new EmbedBuilder().setColor(config.store.color).setTitle('HDT STORE | Emoji & Symbols').setDescription([
        '**Shop:** 🛍️ 🛒 🏷️ 📦', '**Thanh toán:** 💳 💰 🧾 🏦', '**Trạng thái:** ✅ ⏳ ❌ ⚠️',
        '**Ticket:** 🎫 🛟 🔒 📩', '**Trang trí:** ✦ ✧ 𓆩 𓆪 『 』 「 」 ┊ ・ ︱ ⌁',
        '\nCustom emoji của server có thể dùng khi bot được phép truy cập; hãy cấu hình ID emoji hợp lệ nếu muốn dùng emoji riêng.',
      ].join('\n'))] });
    }
    const commandName = ALIASES[requested] || requested;
    const command = message.client.commands.get(commandName);
    if (!command) return;
    if (['qrdone', 'guiacc'].includes(commandName)) {
      const isGui = commandName === 'guiacc';
      const button = new ButtonBuilder()
        .setCustomId(isGui ? 'prefix_modal_guiacc' : 'prefix_modal_qrdone')
        .setLabel(isGui ? 'Mở biểu mẫu bàn giao' : 'Gửi thông tin thanh toán')
        .setStyle(isGui ? ButtonStyle.Secondary : ButtonStyle.Primary);
      return message.reply({
        content: isGui ? 'Bấm nút bên dưới để mở biểu mẫu bàn giao bảo mật.' : 'Bấm nút bên dưới để mở biểu mẫu xác nhận thanh toán.',
        components: [new ActionRowBuilder().addComponents(button)],
      });
    }
    try {
      const adapter = makeAdapter(message, command, tokens);
      await command.execute(adapter);
    } catch (error) {
      console.error(`[PREFIX:${requested}]`, error);
      return message.reply('❌ Không thể thực hiện lệnh này. Kiểm tra cú pháp bằng `-help` hoặc xem log bot.').catch(() => {});
    }
  },
};
