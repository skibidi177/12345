// src/events/ready.js
const paymentService = require('../services/paymentService');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`[BOT] Đăng nhập thành công với tên ${client.user.tag}`);

    // Sweep expired PENDING payments every minute.
    setInterval(async () => {
      try {
        const count = await paymentService.expireDuePayments();
        if (count > 0) console.log(`[PAYMENT] Đã đánh dấu ${count} payment(s) EXPIRED.`);
      } catch (err) {
        console.error('[PAYMENT] Lỗi khi expire payments:', err.message);
      }
    }, 60 * 1000);
  },
};
