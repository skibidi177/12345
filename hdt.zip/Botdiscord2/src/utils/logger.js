// src/utils/logger.js
// Centralized, safe logging. Never pass password/secret fields into these.
const AdminLog = require('../models/AdminLog');
const SecurityLog = require('../models/SecurityLog');

async function sendChannelLog(client, channelId, embed) {
  if (!channelId) return;
  try {
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel && channel.isTextBased()) {
      await channel.send({ embeds: [embed] });
    }
  } catch (err) {
    console.error('[LOGGER] Failed to send channel log:', err.message);
  }
}

async function logAdminAction(action, actorId, targetId, detail) {
  try {
    await AdminLog.create({ action, actorId, targetId, detail });
  } catch (err) {
    console.error('[LOGGER] Failed to write admin log:', err.message);
  }
}

async function logSecurityEvent(event, actorId, detail) {
  try {
    await SecurityLog.create({ event, actorId, detail });
  } catch (err) {
    console.error('[LOGGER] Failed to write security log:', err.message);
  }
}

module.exports = { sendChannelLog, logAdminAction, logSecurityEvent };
