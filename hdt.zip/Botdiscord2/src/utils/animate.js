// src/utils/animate.js
// Discord embeds can't truly animate, so "chuyển động" in this bot is done the
// way real Discord products do it: a message is written, then edited a few
// times in quick succession (a loading spinner, a step-by-step status, a
// progress bar) before settling on its final state. Used for QR generation,
// ticket creation, and payment verification so those moments feel alive
// instead of a flat instant reply.

const SPINNER_FRAMES = ['◐', '◓', '◑', '◒'];

function spinner(step = 0) {
  return SPINNER_FRAMES[step % SPINNER_FRAMES.length];
}

// Renders a compact block progress bar, e.g. progressBar(3, 10) -> "▰▰▰▱▱▱▱▱▱▱"
function progressBar(current, max, length = 12) {
  const safeMax = max > 0 ? max : 1;
  const ratio = Math.max(0, Math.min(1, current / safeMax));
  const filled = Math.round(ratio * length);
  return '▰'.repeat(filled) + '▱'.repeat(length - filled);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Plays a short sequence of embeds on an already-deferred interaction by
// editing the reply in place. `steps` is an array of EmbedBuilder instances.
async function playInteractionSequence(interaction, steps, { delay = 500 } = {}) {
  for (let i = 0; i < steps.length; i++) {
    try {
      await interaction.editReply({ embeds: [steps[i]] });
    } catch (_) {
      return; // interaction expired mid-sequence - stop quietly, no crash
    }
    if (i < steps.length - 1) await sleep(delay);
  }
}

// Same idea but for a plain channel message (used by long-running background
// flows like the /qrdone auto-check loop, which outlives any one interaction).
async function playMessageSequence(message, steps, { delay = 500 } = {}) {
  for (let i = 0; i < steps.length; i++) {
    try {
      await message.edit({ embeds: [steps[i]] });
    } catch (_) {
      return;
    }
    if (i < steps.length - 1) await sleep(delay);
  }
}

module.exports = { spinner, progressBar, sleep, playInteractionSequence, playMessageSequence };
