// src/utils/orderId.js
const Counter = require('../models/Counter');

async function generateOrderId() {
  const year = new Date().getFullYear();
  const counterKey = `order-${year}`;
  const counter = await Counter.findOneAndUpdate(
    { _id: counterKey },
    { $inc: { seq: 1 } },
    { upsert: true, new: true }
  );
  const seq = String(counter.seq).padStart(6, '0');
  return `HDT-${year}-${seq}`;
}

async function generatePaymentId() {
  const counter = await Counter.findOneAndUpdate(
    { _id: 'payment-global' },
    { $inc: { seq: 1 } },
    { upsert: true, new: true }
  );
  const seq = counter.seq.toString(16).toUpperCase().padStart(6, '0');
  return `PAY-${seq}`;
}

async function generateAccountRequestId() {
  const counter = await Counter.findOneAndUpdate(
    { _id: 'account-request-global' },
    { $inc: { seq: 1 } },
    { upsert: true, new: true }
  );
  return `ACC-${String(counter.seq).padStart(6, '0')}`;
}

module.exports = { generateOrderId, generatePaymentId, generateAccountRequestId };
