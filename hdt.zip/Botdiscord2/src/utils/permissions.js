// src/utils/permissions.js
// All permission checks happen server-side against configured role/user IDs -
// never inferred purely from which Discord UI element was clicked.
const config = require('../config/config');

function isOwner(userId) {
  return userId === config.discord.ownerId;
}

function memberHasRole(member, roleId) {
  if (!roleId || !member) return false;
  return member.roles.cache.has(roleId);
}

function isAdmin(member) {
  if (!member) return false;
  if (isOwner(member.id)) return true;
  return memberHasRole(member, config.roles.admin) || memberHasRole(member, config.roles.manager);
}

function isStaff(member) {
  if (!member) return false;
  if (isAdmin(member)) return true;
  return memberHasRole(member, config.roles.staff) || memberHasRole(member, config.roles.support);
}

function isPaymentStaff(member) {
  if (!member) return false;
  if (isStaff(member)) return true;
  return config.roles.paymentStaff.some((roleId) => memberHasRole(member, roleId));
}

module.exports = { isOwner, isAdmin, isStaff, isPaymentStaff, memberHasRole };
