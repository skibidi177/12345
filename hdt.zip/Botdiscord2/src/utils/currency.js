// src/utils/currency.js
// Formats VND amounts into the short "k / tr" notation used across the store,
// per spec section 54-55. Real integer VND amounts are always used for
// database, API and reconciliation - never the formatted string.

function formatVND(amount) {
  const n = Number(amount);
  if (!Number.isFinite(n)) return '0k';

  if (n < 1000000) {
    const k = n / 1000;
    // Keep it clean: no decimals for whole thousands (the common case)
    const kRounded = Math.round(k * 10) / 10;
    const str = Number.isInteger(kRounded) ? String(kRounded) : kRounded.toFixed(1).replace('.', ',');
    return `${str}k`;
  }

  const tr = n / 1000000;
  const trRounded = Math.round(tr * 10) / 10;
  const str = Number.isInteger(trRounded) ? String(trRounded) : trRounded.toFixed(1).replace('.', ',');
  return `${str}tr`;
}

// Full "99.000 ₫" style formatting - reserved for receipts / admin exports
// where exact figures are preferred over the shorthand.
function formatVNDFull(amount) {
  const n = Number(amount) || 0;
  return `${n.toLocaleString('vi-VN')} ₫`;
}

module.exports = { formatVND, formatVNDFull };
