// src/utils/embeds.js
// Central embed factory. Every embed in the bot shares the same signature
// look (color palette, footer tagline, optional thumbnail/banner) so the
// store reads as one coherent product instead of a pile of ad-hoc messages.
const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

const PALETTE = {
  default: config.store.color,
  success: '#2ecc71',
  error: '#c0392b',
  warning: '#b8860b',
  premium: '#c9a227',
};

const DIVIDER = '─'.repeat(26);

function baseEmbed(color) {
  const embed = new EmbedBuilder()
    .setColor(color || PALETTE.default)
    .setFooter({ text: `${config.store.name}  ·  ${config.store.tagline}` })
    .setTimestamp();
  if (config.store.thumbnailUrl) embed.setThumbnail(config.store.thumbnailUrl);
  return embed;
}

/**
 * General-purpose embed.
 * opts (all optional): { color, fields: [{name, value, inline}], banner: bool, image: url, footer: 'override' }
 */
function storeEmbed(title, description, opts = {}) {
  const embed = baseEmbed(opts.color).setTitle(title);
  if (description) embed.setDescription(description);
  if (opts.fields && opts.fields.length) embed.addFields(opts.fields);
  if (opts.banner && config.store.bannerUrl) embed.setImage(config.store.bannerUrl);
  if (opts.image) embed.setImage(opts.image);
  if (opts.footer) embed.setFooter({ text: opts.footer });
  return embed;
}

function errorEmbed(code, message, opts = {}) {
  const embed = baseEmbed(PALETTE.error)
    .setTitle('Đã xảy ra lỗi')
    .setDescription(`${message || 'Đã xảy ra lỗi khi xử lý yêu cầu.'}\n\nMã lỗi: \`${code}\``);
  if (opts.fields && opts.fields.length) embed.addFields(opts.fields);
  return embed;
}

function successEmbed(title, description, opts = {}) {
  const embed = baseEmbed(PALETTE.success).setTitle(title);
  if (description) embed.setDescription(description);
  if (opts.fields && opts.fields.length) embed.addFields(opts.fields);
  return embed;
}

function warningEmbed(title, description, opts = {}) {
  const embed = baseEmbed(PALETTE.warning).setTitle(title);
  if (description) embed.setDescription(description);
  if (opts.fields && opts.fields.length) embed.addFields(opts.fields);
  return embed;
}

function premiumEmbed(title, description, opts = {}) {
  const embed = baseEmbed(PALETTE.premium).setTitle(title);
  if (description) embed.setDescription(description);
  if (opts.fields && opts.fields.length) embed.addFields(opts.fields);
  return embed;
}

module.exports = { baseEmbed, storeEmbed, errorEmbed, successEmbed, warningEmbed, premiumEmbed, PALETTE, DIVIDER };
