// src/utils/paymentCode.js
// Generates a short, unique, bank-app-friendly transfer code. Never derived
// from a username (usernames may contain diacritics / special characters).
const crypto = require('crypto');
const config = require('../config/config');
const PaymentRequest = require('../models/PaymentRequest');

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no confusing chars (0,O,1,I)

function randomSegment(length) {
  let out = '';
  const bytes = crypto.randomBytes(length);
  for (let i = 0; i < length; i++) {
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return out;
}

async function generateUniqueTransferContent() {
  const prefix = (config.vietqr.transferPrefix || 'HDT').toUpperCase().replace(/[^A-Z0-9]/g, '');
  for (let attempt = 0; attempt < 10; attempt++) {
    const code = `${prefix}${randomSegment(6)}`;
    // VietQR addInfo has a practical length limit - keep codes short.
    if (code.length > 20) continue;
    const exists = await PaymentRequest.findOne({ transferContent: code });
    if (!exists) return code;
  }
  throw new Error('Không thể tạo mã thanh toán duy nhất, vui lòng thử lại.');
}

module.exports = { generateUniqueTransferContent };
