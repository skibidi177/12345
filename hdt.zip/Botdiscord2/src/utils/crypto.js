// src/utils/crypto.js
// AES-256-GCM helpers used to encrypt account credentials at rest.
// The ENCRYPTION_KEY env var must be a 32-byte value (hex or any 32+ char
// string - we hash it down to a stable 32-byte key).
const crypto = require('crypto');
const config = require('../config/config');

function getKey() {
  const raw = config.security.encryptionKey || '';
  if (!raw) throw new Error('ENCRYPTION_KEY chưa được cấu hình trong .env');
  return crypto.createHash('sha256').update(raw).digest(); // 32 bytes
}

function encrypt(plaintext) {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return {
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
    data: encrypted.toString('hex'),
  };
}

function decrypt(payload) {
  if (!payload || !payload.iv || !payload.data || !payload.authTag) return null;
  const key = getKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(payload.iv, 'hex'));
  decipher.setAuthTag(Buffer.from(payload.authTag, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(payload.data, 'hex')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

module.exports = { encrypt, decrypt };
