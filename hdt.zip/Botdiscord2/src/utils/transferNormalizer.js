// src/utils/transferNormalizer.js
// Normalizes bank transfer descriptions for matching. Vietnamese bank apps
// commonly strip diacritics and collapse whitespace/casing, so we mirror that
// here rather than doing "fuzzy" matching.

function stripDiacritics(str) {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/gi, 'd');
}

function normalizeTransferContent(str) {
  if (!str) return '';
  return stripDiacritics(String(str))
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, ''); // remove spaces & punctuation entirely
}

// True only if the expected payment code appears verbatim (post-normalize)
// inside the actual transaction description. Never matches on username or
// customer name, and never matches on amount alone.
function transferContentMatches(expectedCode, actualDescription) {
  const expected = normalizeTransferContent(expectedCode);
  const actual = normalizeTransferContent(actualDescription);
  if (!expected) return false;
  return actual.includes(expected);
}

module.exports = { normalizeTransferContent, transferContentMatches };
