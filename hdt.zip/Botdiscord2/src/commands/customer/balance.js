// src/commands/customer/balance.js
const { SlashCommandBuilder } = require('discord.js');
const { ensureUser } = require('../../services/orderService');
const { storeEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');

module.exports = {
  data: new SlashCommandBuilder().setName('balance').setDescription('Xem số dư tài khoản của bạn'),
  async execute(interaction) {
    const user = await ensureUser(interaction.user.id);
    const embed = storeEmbed(
      'Số dư tài khoản',
      [
        `Số dư hiện tại: **${formatVND(user.balance)}**`,
        `Tổng đã nạp: **${formatVND(user.totalDeposited)}**`,
        `Tổng đã mua: **${formatVND(user.totalSpent)}**`,
      ].join('\n')
    );
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
