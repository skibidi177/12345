// src/commands/customer/order.js
const { SlashCommandBuilder } = require('discord.js');
const orderService = require('../../services/orderService');
const { storeEmbed, errorEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('order')
    .setDescription('Xem thông tin đơn hàng')
    .addStringOption((opt) => opt.setName('order_id').setDescription('Mã đơn hàng').setRequired(true)),
  async execute(interaction) {
    const orderId = interaction.options.getString('order_id');
    const order = await orderService.getOrder(orderId);
    if (!order) {
      return interaction.reply({ embeds: [errorEmbed('ORDER_NOT_FOUND', 'Không tìm thấy đơn hàng này.')], ephemeral: true });
    }
    if (order.userId !== interaction.user.id && !isStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền xem đơn hàng này.')], ephemeral: true });
    }

    const embed = storeEmbed(
      `Đơn hàng ${order.orderId}`,
      [
        `Sản phẩm: **${order.productName}${order.packageLabel ? ' - ' + order.packageLabel : ''}**`,
        `Giá: **${formatVND(order.price)}**`,
        `Trạng thái: **${order.status}**`,
        `Ngày tạo: <t:${Math.floor(order.createdAt.getTime() / 1000)}:F>`,
        order.warrantyExpiresAt ? `Bảo hành đến: <t:${Math.floor(order.warrantyExpiresAt.getTime() / 1000)}:D>` : null,
      ]
        .filter(Boolean)
        .join('\n')
    );
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
