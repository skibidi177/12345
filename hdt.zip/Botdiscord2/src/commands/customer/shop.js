// src/commands/customer/shop.js
const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const config = require('../../config/config');
const { storeEmbed, DIVIDER } = require('../../utils/embeds');
const { spinner, playInteractionSequence } = require('../../utils/animate');

module.exports = {
  data: new SlashCommandBuilder().setName('shop').setDescription('Mở giao diện cửa hàng HDT STORE'),
  async execute(interaction) {
    await interaction.deferReply();

    await playInteractionSequence(
      interaction,
      [
        storeEmbed('Đang mở cửa hàng', `${spinner(0)} Đang tải danh mục sản phẩm và kiểm tra tồn kho...`),
        storeEmbed('Đang mở cửa hàng', `${spinner(1)} Sắp xong, đang dựng lại quầy giao dịch của bạn...`),
      ],
      { delay: 380 }
    );

    const embed = storeEmbed(
      config.store.name,
      [
        `Một điểm dừng chân, mọi nhu cầu tài khoản số của bạn đều có ở đây. Từ giải trí, sáng tạo nội dung cho đến kết nối cộng đồng — ${config.store.name} chọn lọc kỹ càng để mỗi giao dịch đều xứng đáng với niềm tin bạn đặt vào chúng tôi.`,
        DIVIDER,
      ].join('\n')
    ).addFields(
      { name: 'Mua hàng', value: 'Duyệt danh mục và chọn gói phù hợp với bạn.', inline: true },
      { name: 'Sản phẩm', value: 'Xem toàn bộ bảng giá và tình trạng kho.', inline: true },
      { name: 'Nạp tiền', value: 'Tạo mã QR nạp số dư vào tài khoản.', inline: true },
      { name: 'Ticket', value: 'Mở phòng riêng để được đội ngũ hỗ trợ trực tiếp.', inline: true },
      { name: 'Lịch sử đơn hàng', value: 'Theo dõi các đơn đã và đang xử lý.', inline: true },
      { name: 'Tài khoản', value: 'Xem hồ sơ, số dư và hạng thành viên.', inline: true }
    );

    const menu = new StringSelectMenuBuilder()
      .setCustomId('shop_main_menu')
      .setPlaceholder('Chọn chức năng HDT STORE')
      .addOptions(
        { label: 'Mua hàng', description: 'Duyệt danh mục và chọn sản phẩm', value: 'buy', emoji: '🛍️' },
        { label: 'Bảng giá sản phẩm', description: 'Xem giá và tình trạng kho', value: 'products', emoji: '📦' },
        { label: 'Nạp tiền', description: 'Tạo mã QR nạp số dư', value: 'deposit', emoji: '💳' },
        { label: 'Ticket hỗ trợ', description: 'Mở phòng hỗ trợ riêng tư', value: 'ticket', emoji: '🎫' },
        { label: 'Lịch sử đơn hàng', description: 'Theo dõi đơn hàng của bạn', value: 'history', emoji: '🧾' },
        { label: 'Tài khoản', description: 'Xem hồ sơ và hạng thành viên', value: 'account', emoji: '👤' },
        { label: 'Hướng dẫn', description: 'Cách mua hàng và thanh toán', value: 'guide', emoji: '📖' }
      );
    const row = new ActionRowBuilder().addComponents(menu);
    await interaction.editReply({ embeds: [embed], components: [row] });
  },
};
