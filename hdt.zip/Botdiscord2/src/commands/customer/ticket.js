// src/commands/customer/ticket.js
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config/config');
const { storeEmbed, DIVIDER } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('ticket').setDescription('Mở bảng tạo ticket hỗ trợ'),
  async execute(interaction) {
    const embed = storeEmbed(
      `${config.store.name} — SUPPORT`,
      [
        `Cần hỗ trợ? Chọn đúng lý do bên dưới và một phòng riêng tư sẽ được mở ra chỉ giữa bạn và đội ngũ ${config.store.name}. Mọi cuộc trò chuyện tại đây đều được lưu lại để đảm bảo quyền lợi cho bạn.`,
        DIVIDER,
      ].join('\n')
    );

    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_open_MUA_HANG').setLabel('Mua hàng').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ticket_open_HO_TRO').setLabel('Hỗ trợ').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket_open_THANH_TOAN').setLabel('Thanh toán').setStyle(ButtonStyle.Secondary)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_open_BAO_HANH').setLabel('Bảo hành').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ticket_open_KHAC').setLabel('Khác').setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({ embeds: [embed], components: [row1, row2] });
  },
};
