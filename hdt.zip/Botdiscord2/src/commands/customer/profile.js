// src/commands/customer/profile.js
const { SlashCommandBuilder } = require('discord.js');
const { ensureUser } = require('../../services/orderService');
const { storeEmbed, premiumEmbed, DIVIDER } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { progressBar } = require('../../utils/animate');
const config = require('../../config/config');

const TIERS = [
  { key: 'Bronze', min: config.loyalty.bronze },
  { key: 'Silver', min: config.loyalty.silver },
  { key: 'Gold', min: config.loyalty.gold },
  { key: 'Diamond', min: config.loyalty.diamond },
];

function loyaltyInfo(totalSpent) {
  let current = TIERS[0];
  let next = TIERS[1];
  for (let i = 0; i < TIERS.length; i++) {
    if (totalSpent >= TIERS[i].min) {
      current = TIERS[i];
      next = TIERS[i + 1] || null;
    }
  }
  return { current: current.key, next };
}

module.exports = {
  data: new SlashCommandBuilder().setName('profile').setDescription('Xem hồ sơ khách hàng của bạn'),
  async execute(interaction) {
    const user = await ensureUser(interaction.user.id);
    const { current, next } = loyaltyInfo(user.totalSpent);

    const buildEmbed = current === 'Diamond' ? premiumEmbed : storeEmbed;
    const embed = buildEmbed(
      `${config.store.name} PROFILE`,
      [`Hồ sơ giao dịch của <@${interaction.user.id}> tại ${config.store.name}.`, DIVIDER].join('\n')
    ).addFields(
      { name: 'Số dư', value: `**${formatVND(user.balance)}**`, inline: true },
      { name: 'Tổng chi tiêu', value: `**${formatVND(user.totalSpent)}**`, inline: true },
      { name: 'Hạng thành viên', value: `**${current}**`, inline: true },
      { name: 'Tổng đơn hàng', value: `${user.totalOrders}`, inline: true },
      { name: 'Đơn hoàn thành', value: `${user.completedOrders}`, inline: true },
      { name: 'Tham gia', value: `<t:${Math.floor(user.joinedStoreAt.getTime() / 1000)}:D>`, inline: true }
    );

    if (next) {
      const base = TIERS.find((t) => t.key === current).min;
      const progressed = Math.max(0, user.totalSpent - base);
      const needed = next.min - base;
      embed.addFields({
        name: `Tiến độ lên hạng ${next.key}`,
        value: `${progressBar(progressed, needed)}\n${formatVND(user.totalSpent)} / ${formatVND(next.min)}`,
      });
    } else {
      embed.addFields({ name: 'Hạng cao nhất', value: 'Bạn đã đạt hạng thành viên cao nhất của cửa hàng.' });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
