// src/commands/customer/history.js
const { SlashCommandBuilder } = require('discord.js');
const orderService = require('../../services/orderService');
const { storeEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');

module.exports = {
  data: new SlashCommandBuilder().setName('history').setDescription('Xem lịch sử đơn hàng của bạn'),
  async execute(interaction) {
    const orders = await orderService.listOrdersByUser(interaction.user.id, 10);
    if (!orders.length) {
      return interaction.reply({ embeds: [storeEmbed('Lịch sử đơn hàng', 'Bạn chưa có đơn hàng nào.')], ephemeral: true });
    }
    const lines = orders.map(
      (o) => `\`${o.orderId}\` — ${o.productName} — ${formatVND(o.price)} — **${o.status}**`
    );
    await interaction.reply({ embeds: [storeEmbed('Lịch sử đơn hàng (10 gần nhất)', lines.join('\n'))], ephemeral: true });
  },
};
