// src/commands/customer/deposit.js
const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const paymentService = require('../../services/paymentService');
const { storeEmbed, errorEmbed, DIVIDER } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const config = require('../../config/config');
const { spinner, playInteractionSequence } = require('../../utils/animate');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deposit')
    .setDescription('Nạp tiền vào tài khoản HDT STORE')
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('Số tiền muốn nạp (VNĐ)').setRequired(true).setMinValue(10000)
    ),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    await interaction.deferReply({ ephemeral: true });

    await playInteractionSequence(
      interaction,
      [
        storeEmbed('Đang tạo phiếu nạp tiền', `${spinner(0)} Đang sinh mã giao dịch riêng cho bạn...`),
        storeEmbed('Đang tạo phiếu nạp tiền', `${spinner(1)} Đang kết nối cổng VietQR...`),
      ],
      { delay: 420 }
    );

    try {
      const payment = await paymentService.createPayment({
        kind: 'DEPOSIT',
        ticketId: null,
        customerId: interaction.user.id,
        createdBy: interaction.user.id,
        amount,
      });

      const base64 = payment.qrDataURL.split(',')[1];
      const attachment = new AttachmentBuilder(Buffer.from(base64, 'base64'), { name: 'vietqr.png' });

      const embed = storeEmbed(
        `${config.store.name} — NẠP TIỀN`,
        [`Quét mã bên dưới để nạp tiền vào số dư của bạn. Số dư sẽ được cộng tự động ngay khi hệ thống xác nhận giao dịch.`, DIVIDER].join('\n')
      )
        .addFields(
          { name: 'Số tiền', value: `**${formatVND(amount)}**`, inline: true },
          { name: 'Ngân hàng', value: `**${config.vietqr.bankName}**`, inline: true },
          { name: 'Hết hạn', value: `<t:${Math.floor(payment.expiresAt.getTime() / 1000)}:R>`, inline: true },
          { name: 'Số tài khoản', value: `\`${config.vietqr.accountNumber}\``, inline: true },
          { name: 'Chủ tài khoản', value: `**${config.vietqr.accountName}**`, inline: true },
          {
            name: 'Nội dung chuyển khoản (bắt buộc)',
            value: `\`${payment.transferContent}\`\n\nVui lòng chuyển đúng số tiền và đúng nội dung trên để hệ thống nhận diện giao dịch chính xác.`,
          }
        )
        .setImage('attachment://vietqr.png');

      await interaction.editReply({ embeds: [embed], files: [attachment] });
    } catch (err) {
      console.error('[DEPOSIT]', err.message);
      await interaction.editReply({ embeds: [errorEmbed('DEPOSIT_QR_FAILED', 'Không thể tạo mã QR nạp tiền lúc này.')] });
    }
  },
};
