// src/commands/customer/qrdone.js
const { SlashCommandBuilder } = require('discord.js');
const ticketService = require('../../services/ticketService');
const paymentService = require('../../services/paymentService');
const { errorEmbed } = require('../../utils/embeds');
const { buildQrDoneModal } = require('../../modals/qrdoneModal');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('qrdone')
    .setDescription('Báo cho staff rằng bạn đã hoàn tất chuyển khoản'),
  async execute(interaction) {
    const ticket = await ticketService.getTicketByChannel(interaction.channel.id);
    if (!ticket || ticket.userId !== interaction.user.id) {
      return interaction.reply({
        embeds: [errorEmbed('NOT_IN_TICKET', 'Lệnh này chỉ có thể sử dụng bên trong ticket của bạn.')],
        ephemeral: true,
      });
    }

    const payment = await paymentService.getPendingForTicket(interaction.channel.id);
    if (!payment) {
      return interaction.reply({
        embeds: [errorEmbed('NO_PENDING_PAYMENT', 'Ticket này hiện không có giao dịch thanh toán đang chờ.')],
        ephemeral: true,
      });
    }
    if (payment.expiresAt.getTime() < Date.now()) {
      return interaction.reply({
        embeds: [errorEmbed('PAYMENT_EXPIRED', 'Mã thanh toán đã hết hạn. Vui lòng yêu cầu Staff tạo mã QR mới.')],
        ephemeral: true,
      });
    }

    await interaction.showModal(buildQrDoneModal(payment.paymentId));
  },
};
