// src/commands/owner/stats.js
const { SlashCommandBuilder } = require('discord.js');
const statsService = require('../../services/statsService');
const { premiumEmbed, errorEmbed, DIVIDER } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isAdmin } = require('../../utils/permissions');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder().setName('stats').setDescription('[OWNER] Xem thống kê doanh thu'),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ OWNER/ADMIN mới có thể sử dụng lệnh này.')], ephemeral: true });
    }

    const s = await statsService.overview();
    const topProducts = s.topProducts.map((p, i) => `${i + 1}. ${p._id} — ${p.count} đơn — ${formatVND(p.revenue)}`).join('\n') || '_Chưa có dữ liệu_';
    const topCustomers = s.topCustomers.map((c, i) => `${i + 1}. <@${c._id}> — ${formatVND(c.total)}`).join('\n') || '_Chưa có dữ liệu_';

    const embed = premiumEmbed(
      `${config.store.name} — THỐNG KÊ`,
      [`Toàn cảnh hoạt động kinh doanh của cửa hàng tính đến thời điểm hiện tại.`, DIVIDER].join('\n')
    ).addFields(
      { name: 'Hôm nay', value: `**${formatVND(s.today.total)}**\n${s.today.count} đơn`, inline: true },
      { name: 'Tuần này', value: `**${formatVND(s.week.total)}**\n${s.week.count} đơn`, inline: true },
      { name: 'Tháng này', value: `**${formatVND(s.month.total)}**\n${s.month.count} đơn`, inline: true },
      { name: 'Tổng doanh thu', value: `**${formatVND(s.allTime.total)}**\n${s.allTime.count} đơn`, inline: true },
      { name: 'Đơn hoàn thành', value: `${s.completed}`, inline: true },
      { name: 'Đơn hủy', value: `${s.cancelled}`, inline: true },
      { name: 'Sản phẩm bán chạy', value: topProducts },
      { name: 'Khách hàng mua nhiều nhất', value: topCustomers }
    );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
