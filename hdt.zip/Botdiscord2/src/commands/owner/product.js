// src/commands/owner/product.js
const { SlashCommandBuilder } = require('discord.js');
const productService = require('../../services/productService');
const { storeEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isAdmin } = require('../../utils/permissions');
const { logAdminAction, sendChannelLog } = require('../../utils/logger');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('product')
    .setDescription('[OWNER] Quản lý sản phẩm')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Thêm sản phẩm mới')
        .addStringOption((o) => o.setName('product_id').setDescription('ID sản phẩm (slug), vd: youtube-personal').setRequired(true))
        .addStringOption((o) => o.setName('category').setDescription('Danh mục, vd: YouTube Premium').setRequired(true))
        .addStringOption((o) => o.setName('name').setDescription('Tên gói, vd: Cá nhân').setRequired(true))
        .addIntegerOption((o) => o.setName('price').setDescription('Giá (VNĐ)').setRequired(true))
        .addStringOption((o) => o.setName('package_label').setDescription('Nhãn gói, vd: 1 tháng').setRequired(false))
        .addStringOption((o) => o.setName('description').setDescription('Mô tả').setRequired(false))
        .addIntegerOption((o) => o.setName('stock').setDescription('Số lượng tồn kho').setRequired(false))
        .addIntegerOption((o) => o.setName('warranty_days').setDescription('Số ngày bảo hành').setRequired(false))
    )
    .addSubcommand((sub) =>
      sub.setName('remove').setDescription('Xóa sản phẩm').addStringOption((o) => o.setName('product_id').setDescription('ID sản phẩm').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('price')
        .setDescription('Cập nhật giá sản phẩm')
        .addStringOption((o) => o.setName('product_id').setDescription('ID sản phẩm').setRequired(true))
        .addIntegerOption((o) => o.setName('price').setDescription('Giá mới (VNĐ)').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('stock')
        .setDescription('Cập nhật tồn kho')
        .addStringOption((o) => o.setName('product_id').setDescription('ID sản phẩm').setRequired(true))
        .addIntegerOption((o) => o.setName('amount').setDescription('Số lượng tồn kho mới').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('toggle').setDescription('Bật/tắt sản phẩm').addStringOption((o) => o.setName('product_id').setDescription('ID sản phẩm').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('Danh sách sản phẩm')),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ OWNER/ADMIN mới có thể sử dụng lệnh này.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const productId = interaction.options.getString('product_id');
      const existing = await productService.getProduct(productId);
      if (existing) return interaction.reply({ embeds: [errorEmbed('DUPLICATE_PRODUCT', 'Product ID này đã tồn tại.')], ephemeral: true });

      const product = await productService.createProduct({
        productId,
        category: interaction.options.getString('category'),
        name: interaction.options.getString('name'),
        price: interaction.options.getInteger('price'),
        packageLabel: interaction.options.getString('package_label') || '',
        description: interaction.options.getString('description') || '',
        stock: interaction.options.getInteger('stock') ?? 0,
        warrantyDays: interaction.options.getInteger('warranty_days') ?? 30,
      });

      await logAdminAction('PRODUCT_ADD', interaction.user.id, productId, `price=${product.price}`);
      await sendChannelLog(interaction.client, config.channels.adminLog, storeEmbed('Product Added', `\`${productId}\` — ${product.category} / ${product.name} — ${formatVND(product.price)}`));
      return interaction.reply({ embeds: [successEmbed('Đã thêm sản phẩm', `\`${productId}\` đã được thêm.`)], ephemeral: true });
    }

    if (sub === 'remove') {
      const productId = interaction.options.getString('product_id');
      const removed = await productService.removeProduct(productId);
      if (!removed) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy sản phẩm.')], ephemeral: true });
      await logAdminAction('PRODUCT_REMOVE', interaction.user.id, productId, '');
      return interaction.reply({ embeds: [successEmbed('Đã xóa', `\`${productId}\` đã bị xóa.`)], ephemeral: true });
    }

    if (sub === 'price') {
      const productId = interaction.options.getString('product_id');
      const price = interaction.options.getInteger('price');
      const product = await productService.setPrice(productId, price);
      if (!product) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy sản phẩm.')], ephemeral: true });
      await logAdminAction('PRODUCT_PRICE_CHANGE', interaction.user.id, productId, `newPrice=${price}`);
      await sendChannelLog(interaction.client, config.channels.adminLog, storeEmbed('Price Changed', `\`${productId}\` → ${formatVND(price)}\nBởi: <@${interaction.user.id}>`));
      return interaction.reply({ embeds: [successEmbed('Đã cập nhật giá', `\`${productId}\` → **${formatVND(price)}**`)], ephemeral: true });
    }

    if (sub === 'stock') {
      const productId = interaction.options.getString('product_id');
      const amount = interaction.options.getInteger('amount');
      const product = await productService.setStock(productId, amount);
      if (!product) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy sản phẩm.')], ephemeral: true });
      await logAdminAction('PRODUCT_STOCK_CHANGE', interaction.user.id, productId, `newStock=${amount}`);
      await sendChannelLog(interaction.client, config.channels.adminLog, storeEmbed('Stock Changed', `\`${productId}\` → ${amount}\nBởi: <@${interaction.user.id}>`));
      return interaction.reply({ embeds: [successEmbed('Đã cập nhật tồn kho', `\`${productId}\` → **${amount}**`)], ephemeral: true });
    }

    if (sub === 'toggle') {
      const productId = interaction.options.getString('product_id');
      const product = await productService.toggleActive(productId);
      if (!product) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy sản phẩm.')], ephemeral: true });
      await logAdminAction('PRODUCT_TOGGLE', interaction.user.id, productId, `active=${product.active}`);
      return interaction.reply({ embeds: [successEmbed('Đã cập nhật', `\`${productId}\` giờ đang **${product.active ? 'BẬT' : 'TẮT'}**`)], ephemeral: true });
    }

    if (sub === 'list') {
      const products = await productService.listProducts(null, { onlyActive: false });
      if (!products.length) return interaction.reply({ embeds: [storeEmbed('Danh sách sản phẩm', 'Chưa có sản phẩm nào.')], ephemeral: true });
      const lines = products.map(
        (p) => `\`${p.productId}\` — ${p.category} / ${p.name} — ${formatVND(p.price)} — Stock: ${p.stock} — Đã bán: ${p.sold} — ${p.active ? '**BẬT**' : '**TẮT**'}`
      );
      return interaction.reply({ embeds: [storeEmbed('Danh sách sản phẩm', lines.join('\n'))], ephemeral: true });
    }
  },
};
