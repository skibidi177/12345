// src/commands/owner/owner.js
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { premiumEmbed, errorEmbed, DIVIDER } = require('../../utils/embeds');
const { isOwner } = require('../../utils/permissions');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder().setName('owner').setDescription('[OWNER] Menu quản trị hệ thống'),
  async execute(interaction) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ OWNER mới có thể sử dụng lệnh này.')], ephemeral: true });
    }

    const embed = premiumEmbed(
      `${config.store.name} — OWNER MENU`,
      [`Toàn quyền điều hành cửa hàng nằm trong tay bạn. Dưới đây là các công cụ quản trị đang sẵn sàng.`, DIVIDER].join('\n')
    ).addFields(
      { name: 'Product Manager', value: '`-product add|remove|price|stock|toggle|list`', inline: true },
      { name: 'Order Manager', value: '`-staff orders`', inline: true },
      { name: 'Statistics', value: '`-stats`', inline: true },
      { name: 'Payment Manager', value: '`-payment list|search|cancel`', inline: true },
      { name: 'Account Delivery', value: '`-guiacc` (bảo mật, chỉ Owner)', inline: true },
      { name: 'System', value: 'Cấu hình trong `.env`', inline: true }
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('owner_quick_stats').setLabel('Xem nhanh Stats').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('owner_quick_products').setLabel('Xem nhanh Sản phẩm').setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  },
};
