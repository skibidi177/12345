// src/commands/owner/guiacc.js
const { SlashCommandBuilder } = require('discord.js');
const config = require('../../config/config');
const { errorEmbed } = require('../../utils/embeds');
const { logSecurityEvent } = require('../../utils/logger');
const { buildGuiAccModal } = require('../../modals/guiaccModal');

module.exports = {
  data: new SlashCommandBuilder().setName('guiacc').setDescription('[OWNER ONLY] Bàn giao thông tin tài khoản bảo mật'),
  async execute(interaction) {
    if (interaction.user.id !== config.discord.ownerId) {
      await logSecurityEvent('GUIACC_UNAUTHORIZED_ATTEMPT', interaction.user.id, `channel=${interaction.channel.id}`);
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ OWNER được sử dụng lệnh này.')], ephemeral: true });
    }
    await interaction.showModal(buildGuiAccModal());
  },
};
