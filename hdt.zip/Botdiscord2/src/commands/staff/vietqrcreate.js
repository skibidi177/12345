// src/commands/staff/vietqrcreate.js
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const config = require('../../config/config');
const ticketService = require('../../services/ticketService');
const paymentService = require('../../services/paymentService');
const orderService = require('../../services/orderService');
const { storeEmbed, errorEmbed, warningEmbed, DIVIDER } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isPaymentStaff } = require('../../utils/permissions');
const { sendChannelLog } = require('../../utils/logger');
const { buildPaymentControlRow } = require('../../buttons/paymentButtons');
const { spinner, playInteractionSequence } = require('../../utils/animate');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vietqrcreate')
    .setDescription('[Staff] Tạo mã thanh toán VietQR trong ticket')
    .addIntegerOption((opt) => opt.setName('amount').setDescription('Số tiền cần thu (VNĐ)').setRequired(true).setMinValue(1000)),
  async execute(interaction) {
    if (!isPaymentStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền sử dụng lệnh này.')], ephemeral: true });
    }

    const ticket = await ticketService.getTicketByChannel(interaction.channel.id);
    if (!ticket) {
      return interaction.reply({
        embeds: [errorEmbed('NOT_IN_TICKET', 'Bạn chỉ có thể sử dụng lệnh này bên trong ticket của khách hàng.')],
        ephemeral: true,
      });
    }
    if (!ticket.orderId) {
      return interaction.reply({
        embeds: [errorEmbed('NO_ORDER', 'Ticket này chưa có đơn hàng. Vui lòng tạo Order trước khi tạo thanh toán.')],
        ephemeral: true,
      });
    }

    const amount = interaction.options.getInteger('amount');
    const order = await orderService.getOrder(ticket.orderId);
    if (order && order.price !== amount) {
      await interaction.reply({
        embeds: [errorEmbed('AMOUNT_ORDER_MISMATCH', `Số tiền nhập (${formatVND(amount)}) không khớp với giá đơn hàng (${formatVND(order.price)}). Vui lòng kiểm tra lại trước khi tạo QR.`)],
        ephemeral: true,
      });
      return;
    }

    const existing = await paymentService.getPendingForTicket(interaction.channel.id);
    if (existing) {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`vqr_new:${amount}`).setLabel('Tạo mã mới').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`vqr_keep:${existing.paymentId}`).setLabel('Giữ mã cũ').setStyle(ButtonStyle.Secondary)
      );
      return interaction.reply({
        embeds: [warningEmbed('Đã có yêu cầu thanh toán', 'Ticket này đang có một yêu cầu thanh toán đang chờ.\nBạn có muốn hủy mã cũ và tạo mã mới không?')],
        components: [row],
        ephemeral: true,
      });
    }

    await createAndSendPayment(interaction, ticket, amount);
  },
};

async function createAndSendPayment(interaction, ticket, amount) {
  const isFreshInteraction = !interaction.deferred && !interaction.replied;
  if (isFreshInteraction) await interaction.deferReply();

  await playInteractionSequence(
    interaction,
    [
      storeEmbed('Đang khởi tạo thanh toán', `${spinner(0)} Đang sinh mã giao dịch duy nhất cho đơn hàng \`${ticket.orderId}\`...`),
      storeEmbed('Đang khởi tạo thanh toán', `${spinner(1)} Đang kết nối cổng VietQR và dựng mã QR...`),
      storeEmbed('Đang khởi tạo thanh toán', `${spinner(2)} Gần xong rồi, đang hoàn thiện phiếu thanh toán của bạn...`),
    ],
    { delay: 480 }
  );

  try {
    const payment = await paymentService.createPayment({
      kind: 'ORDER',
      orderId: ticket.orderId,
      ticketId: interaction.channel.id,
      customerId: ticket.userId,
      createdBy: interaction.user.id,
      amount,
    });

    const base64 = payment.qrDataURL.split(',')[1];
    const attachment = new AttachmentBuilder(Buffer.from(base64, 'base64'), { name: 'vietqr.png' });

    const embed = storeEmbed(
      `${config.store.name} — PHIẾU THANH TOÁN`,
      [
        `Vui lòng quét mã QR bên dưới bằng ứng dụng ngân hàng của bạn để hoàn tất đơn hàng \`${ticket.orderId}\`.`,
        DIVIDER,
      ].join('\n')
    )
      .addFields(
        { name: 'Số tiền', value: `**${formatVND(amount)}**`, inline: true },
        { name: 'Ngân hàng', value: `**${config.vietqr.bankName}**`, inline: true },
        { name: 'Mã thanh toán', value: `\`${payment.paymentId}\``, inline: true },
        { name: 'Số tài khoản', value: `\`${config.vietqr.accountNumber}\``, inline: true },
        { name: 'Chủ tài khoản', value: `**${config.vietqr.accountName}**`, inline: true },
        { name: 'Hết hạn', value: `<t:${Math.floor(payment.expiresAt.getTime() / 1000)}:R>`, inline: true },
        {
          name: 'Nội dung chuyển khoản (bắt buộc)',
          value: `\`${payment.transferContent}\`\n\nVui lòng chuyển đúng số tiền và đúng nội dung trên. Nếu sai nội dung, hệ thống có thể không tự động nhận diện được giao dịch của bạn.`,
        }
      )
      .setImage('attachment://vietqr.png');

    await interaction.editReply({
      content: `<@${ticket.userId}>`,
      embeds: [embed],
      files: [attachment],
      components: [buildPaymentControlRow(payment.paymentId)],
    });

    await sendChannelLog(
      interaction.client,
      config.channels.paymentLog,
      storeEmbed('Payment Created', `Payment ID: \`${payment.paymentId}\`\nOrder ID: \`${ticket.orderId}\`\nCustomer: <@${ticket.userId}>\nCreated By: <@${interaction.user.id}>\nAmount: **${formatVND(amount)}**\nTransfer Content: \`${payment.transferContent}\`\nStatus: PENDING`)
    );
  } catch (err) {
    console.error('[VIETQRCREATE]', err.message);
    await interaction.editReply({ embeds: [errorEmbed('VIETQR_CREATE_FAILED', 'Không thể tạo mã QR thanh toán lúc này.')] });
  }
}

module.exports.createAndSendPayment = createAndSendPayment;
