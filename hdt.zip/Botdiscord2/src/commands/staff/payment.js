// src/commands/staff/payment.js
const { SlashCommandBuilder } = require('discord.js');
const paymentService = require('../../services/paymentService');
const paymentVerificationService = require('../../services/paymentVerificationService');
const { storeEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isPaymentStaff } = require('../../utils/permissions');

function paymentSummary(p) {
  return [
    `Payment ID: \`${p.paymentId}\``,
    p.orderId ? `Order ID: \`${p.orderId}\`` : null,
    `Customer: <@${p.customerId}>`,
    `Amount: **${formatVND(p.amount)}**`,
    `Transfer Content: \`${p.transferContent}\``,
    `Status: **${p.status}**`,
    `Expires: <t:${Math.floor(p.expiresAt.getTime() / 1000)}:R>`,
  ]
    .filter(Boolean)
    .join('\n');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('payment')
    .setDescription('[Staff] Quản lý yêu cầu thanh toán')
    .addSubcommand((sub) =>
      sub.setName('info').setDescription('Xem chi tiết một payment').addStringOption((o) => o.setName('payment_id').setDescription('Payment ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('cancel').setDescription('Hủy một payment').addStringOption((o) => o.setName('payment_id').setDescription('Payment ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('check').setDescription('Kiểm tra thủ công một payment').addStringOption((o) => o.setName('payment_id').setDescription('Payment ID').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('Danh sách payment đang PENDING'))
    .addSubcommand((sub) =>
      sub.setName('search').setDescription('Tìm payment theo Order ID').addStringOption((o) => o.setName('order_id').setDescription('Order ID').setRequired(true))
    ),
  async execute(interaction) {
    if (!isPaymentStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền sử dụng lệnh này.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'info') {
      const p = await paymentService.getPayment(interaction.options.getString('payment_id'));
      if (!p) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy payment.')], ephemeral: true });
      return interaction.reply({ embeds: [storeEmbed('Payment Info', paymentSummary(p))], ephemeral: true });
    }

    if (sub === 'cancel') {
      const p = await paymentService.cancelPayment(interaction.options.getString('payment_id'));
      if (!p) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND_OR_NOT_PENDING', 'Không tìm thấy payment đang PENDING.')], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed('Đã hủy', `Payment \`${p.paymentId}\` đã bị hủy.`)] });
    }

    if (sub === 'check') {
      const p = await paymentService.getPayment(interaction.options.getString('payment_id'));
      if (!p) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy payment.')], ephemeral: true });
      const { result, transaction } = await paymentVerificationService.findMatchingTransaction(p);
      if (result === paymentVerificationService.MatchResult.MATCHED) {
        await paymentVerificationService.confirmPayment(p, transaction);
        return interaction.reply({ embeds: [successEmbed('MATCHED', `Payment \`${p.paymentId}\` đã được xác nhận PAID.`)] });
      }
      return interaction.reply({ embeds: [errorEmbed(result, `Kết quả đối soát: ${result}`)], ephemeral: true });
    }

    if (sub === 'list') {
      const list = await paymentService.listPending();
      if (!list.length) return interaction.reply({ embeds: [storeEmbed('Payments đang PENDING', 'Không có payment nào đang chờ.')], ephemeral: true });
      return interaction.reply({ embeds: [storeEmbed('Payments đang PENDING', list.map((p) => `\`${p.paymentId}\` — ${formatVND(p.amount)} — <@${p.customerId}>`).join('\n'))], ephemeral: true });
    }

    if (sub === 'search') {
      const list = await paymentService.searchByOrder(interaction.options.getString('order_id'));
      if (!list.length) return interaction.reply({ embeds: [errorEmbed('NOT_FOUND', 'Không tìm thấy payment cho đơn hàng này.')], ephemeral: true });
      return interaction.reply({ embeds: [storeEmbed('Payments của đơn hàng', list.map((p) => `\`${p.paymentId}\` — ${formatVND(p.amount)} — **${p.status}**`).join('\n'))], ephemeral: true });
    }
  },
};
