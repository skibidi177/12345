// src/commands/staff/staff.js
const { SlashCommandBuilder } = require('discord.js');
const orderService = require('../../services/orderService');
const { storeEmbed, errorEmbed } = require('../../utils/embeds');
const { formatVND } = require('../../utils/currency');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('staff')
    .setDescription('[Staff] Bảng điều khiển staff')
    .addSubcommand((sub) => sub.setName('orders').setDescription('Xem các đơn hàng đang cần xử lý')),
  async execute(interaction) {
    if (!isStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ Staff mới có thể sử dụng lệnh này.')], ephemeral: true });
    }

    const pending = await orderService.listOrdersByStatus('WAITING_PAYMENT');
    const paid = await orderService.listOrdersByStatus('PAID');
    const processing = await orderService.listOrdersByStatus('PROCESSING');

    const section = (title, orders) =>
      `**${title}** (${orders.length})\n` +
      (orders.length ? orders.map((o) => `\`${o.orderId}\` — ${o.productName} — ${formatVND(o.price)}`).join('\n') : '_Không có_');

    await interaction.reply({
      embeds: [storeEmbed('Staff Dashboard', [section('Chờ thanh toán', pending), section('Đã thanh toán', paid), section('Đang xử lý', processing)].join('\n\n'))],
      ephemeral: true,
    });
  },
};
