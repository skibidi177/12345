// src/buttons/accountButtons.js
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config');
const AccountRequest = require('../models/AccountRequest');
const { decrypt } = require('../utils/crypto');
const { errorEmbed, successEmbed } = require('../utils/embeds');
const { isOwner, isStaff } = require('../utils/permissions');
const { logSecurityEvent } = require('../utils/logger');
const ticketService = require('../services/ticketService');

function buildAccountRequestRow(requestId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`acc_reveal:${requestId}`).setLabel('Hiện thông tin').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`acc_ticket:${requestId}`).setLabel('Mở Ticket').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`acc_processed:${requestId}`).setLabel('Đã xử lý').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`acc_delete:${requestId}`).setLabel('Xóa thông tin').setStyle(ButtonStyle.Danger)
  );
}

// Only the Owner and configured Staff/Admin roles may ever see a decrypted password,
// and only as an ephemeral message that nobody else in the channel can read.
function canViewSecret(interaction) {
  return isOwner(interaction.user.id) || isStaff(interaction.member);
}

async function handleAccountButton(interaction) {
  const [action, requestId] = interaction.customId.split(':');

  if (!canViewSecret(interaction)) {
    await logSecurityEvent('ACCOUNT_BUTTON_UNAUTHORIZED', interaction.user.id, `action=${action} requestId=${requestId}`);
    return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền thao tác này.')], ephemeral: true });
  }

  const record = await AccountRequest.findOne({ requestId });
  if (!record) {
    return interaction.reply({ embeds: [errorEmbed('REQUEST_NOT_FOUND', 'Yêu cầu này không tồn tại hoặc đã bị xóa.')], ephemeral: true });
  }

  if (action === 'acc_reveal') {
    if (record.status === 'DELETED' || !record.passwordEnc?.data) {
      return interaction.reply({ embeds: [errorEmbed('ALREADY_DELETED', 'Thông tin này đã bị xóa.')], ephemeral: true });
    }
    const password = decrypt(record.passwordEnc);
    await logSecurityEvent('ACCOUNT_PASSWORD_REVEALED', interaction.user.id, `requestId=${requestId}`);
    return interaction.reply({
      embeds: [
        successEmbed(
          'Thông tin tài khoản',
          [`Product: **${record.productType}**`, `Account: \`${record.account}\``, `Password: \`${password}\``].join('\n')
        ),
      ],
      ephemeral: true,
    });
  }

  if (action === 'acc_processed') {
    record.status = 'DELIVERED';
    record.processedBy = interaction.user.id;
    record.processedAt = new Date();
    record.passwordEnc = { iv: null, authTag: null, data: null }; // purge secret once delivered
    await record.save();
    await logSecurityEvent('ACCOUNT_MARKED_PROCESSED', interaction.user.id, `requestId=${requestId}`);
    return interaction.reply({ embeds: [successEmbed('Đã xử lý', `Yêu cầu \`${requestId}\` đã được đánh dấu hoàn tất và dữ liệu nhạy cảm đã được xóa.`)], ephemeral: true });
  }

  if (action === 'acc_delete') {
    await AccountRequest.deleteOne({ requestId });
    await logSecurityEvent('ACCOUNT_REQUEST_DELETED', interaction.user.id, `requestId=${requestId}`);
    return interaction.reply({ embeds: [successEmbed('Đã xóa', `Yêu cầu \`${requestId}\` đã bị xóa hoàn toàn.`)], ephemeral: true });
  }

  if (action === 'acc_ticket') {
    if (!record.orderId) {
      return interaction.reply({ embeds: [errorEmbed('NO_ORDER', 'Yêu cầu này chưa gắn với đơn hàng nào.')], ephemeral: true });
    }
    return interaction.reply({ embeds: [successEmbed('Mở ticket', `Vui lòng vào ticket của đơn hàng \`${record.orderId}\` để bàn giao.`)], ephemeral: true });
  }
}

module.exports = { buildAccountRequestRow, handleAccountButton };
