// src/buttons/paymentButtons.js
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config');
const paymentService = require('../services/paymentService');
const paymentVerificationService = require('../services/paymentVerificationService');
const { storeEmbed, errorEmbed, successEmbed } = require('../utils/embeds');
const { formatVND } = require('../utils/currency');
const { isPaymentStaff } = require('../utils/permissions');
const { sendChannelLog } = require('../utils/logger');
const { spinner, playInteractionSequence } = require('../utils/animate');

const CHECK_COOLDOWN_MS = 10 * 1000;
const lastCheckByPayment = new Map();

function buildPaymentControlRow(paymentId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pay_done:${paymentId}`).setLabel('Đã thanh toán').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`pay_check:${paymentId}`).setLabel('Kiểm tra thanh toán').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pay_copy:${paymentId}`).setLabel('Sao chép nội dung').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pay_cancel:${paymentId}`).setLabel('Hủy thanh toán').setStyle(ButtonStyle.Danger)
  );
}

async function resolvePaymentEmbed(interaction, payment) {
  const { result, transaction } = await paymentVerificationService.findMatchingTransaction(payment);

  if (result === paymentVerificationService.MatchResult.MATCHED) {
    await paymentVerificationService.confirmPayment(payment, transaction);
    await sendChannelLog(
      interaction.client,
      config.channels.paymentLog,
      storeEmbed('Payment Confirmed', `Payment ID: \`${payment.paymentId}\`\n${payment.orderId ? `Order ID: \`${payment.orderId}\`\n` : ''}Amount: **${formatVND(payment.amount)}**\nReference: \`${transaction.reference}\``)
    );
    return successEmbed(
      'Thanh toán thành công',
      `Giao dịch của bạn đã được xác nhận. Cảm ơn bạn đã tin tưởng ${config.store.name}, đội ngũ Staff sẽ bàn giao sản phẩm ngay sau đây.`
    ).addFields(
      { name: 'Số tiền', value: `**${formatVND(payment.amount)}**`, inline: true },
      { name: 'Mã giao dịch', value: `\`${transaction.reference}\``, inline: true }
    );
  }

  const messages = {
    AMOUNT_MISMATCH: 'Hệ thống tìm thấy giao dịch nhưng số tiền không khớp. Nhân viên sẽ kiểm tra thủ công.',
    CONTENT_MISMATCH: 'Hệ thống tìm thấy giao dịch nhưng nội dung chuyển khoản chưa khớp với mã thanh toán của đơn hàng. Nhân viên sẽ kiểm tra.',
    DESTINATION_MISMATCH: 'Giao dịch không đúng tài khoản nhận của cửa hàng. Nhân viên sẽ kiểm tra.',
    TRANSACTION_ALREADY_USED: 'Giao dịch này đã được sử dụng cho một thanh toán khác.',
    PAYMENT_EXPIRED: 'Mã thanh toán này đã hết hạn. Vui lòng yêu cầu Staff tạo mã mới.',
    TRANSACTION_NOT_FOUND: 'Hệ thống chưa nhận được giao dịch phù hợp. Nếu bạn vừa chuyển khoản, vui lòng chờ thêm một chút rồi thử lại.',
  };

  return errorEmbed(result || 'NOT_FOUND', messages[result] || messages.TRANSACTION_NOT_FOUND);
}

async function handlePaymentButton(interaction) {
  const [action, paymentId] = interaction.customId.split(':');
  const payment = await paymentService.getPayment(paymentId);

  if (!payment) {
    return interaction.reply({ embeds: [errorEmbed('PAYMENT_NOT_FOUND', 'Không tìm thấy yêu cầu thanh toán này.')], ephemeral: true });
  }

  if (action === 'pay_copy') {
    return interaction.reply({ content: `\`${payment.transferContent}\``, ephemeral: true });
  }

  if (action === 'pay_cancel') {
    if (!isPaymentStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ Staff mới có thể hủy thanh toán.')], ephemeral: true });
    }
    await paymentService.cancelPayment(paymentId);
    return interaction.reply({ embeds: [successEmbed('Đã hủy', `Yêu cầu thanh toán \`${paymentId}\` đã bị hủy.`)] });
  }

  if (payment.status !== 'PENDING') {
    return interaction.reply({ embeds: [errorEmbed('PAYMENT_NOT_PENDING', `Yêu cầu thanh toán này đang ở trạng thái ${payment.status}.`)], ephemeral: true });
  }
  if (payment.expiresAt.getTime() < Date.now()) {
    return interaction.reply({ embeds: [errorEmbed('PAYMENT_EXPIRED', 'QR thanh toán này đã hết hạn. Vui lòng yêu cầu Staff tạo mã thanh toán mới.')], ephemeral: true });
  }

  if (action === 'pay_done' || action === 'pay_check') {
    if (action === 'pay_check') {
      const last = lastCheckByPayment.get(paymentId) || 0;
      if (Date.now() - last < CHECK_COOLDOWN_MS) {
        return interaction.reply({ embeds: [errorEmbed('COOLDOWN', 'Vui lòng chờ ít giây trước khi kiểm tra lại.')], ephemeral: true });
      }
      lastCheckByPayment.set(paymentId, Date.now());
    }
    await paymentService.touchLastChecked(paymentId);

    await interaction.deferReply();
    await playInteractionSequence(
      interaction,
      [
        storeEmbed('Đang kiểm tra thanh toán', `${spinner(0)} Đang truy vấn giao dịch ngân hàng...`),
        storeEmbed('Đang kiểm tra thanh toán', `${spinner(1)} Đang đối chiếu số tiền và nội dung chuyển khoản...`),
      ],
      { delay: 480 }
    );

    const embed = await resolvePaymentEmbed(interaction, payment);
    return interaction.editReply({ embeds: [embed] });
  }
}

module.exports = { buildPaymentControlRow, handlePaymentButton };
