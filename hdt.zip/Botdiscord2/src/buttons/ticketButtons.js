// src/buttons/ticketButtons.js
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../config/config');
const ticketService = require('../services/ticketService');
const { storeEmbed, errorEmbed, successEmbed, warningEmbed, DIVIDER } = require('../utils/embeds');
const { isStaff } = require('../utils/permissions');
const { sendChannelLog } = require('../utils/logger');
const { spinner, playInteractionSequence } = require('../utils/animate');

const TYPE_DISPLAY = {
  MUA_HANG: 'Mua hàng',
  HO_TRO: 'Hỗ trợ',
  THANH_TOAN: 'Thanh toán',
  BAO_HANH: 'Bảo hành',
  KHAC: 'Khác',
};

function buildTicketControlRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('ticket_add').setLabel('Add User').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_remove').setLabel('Remove User').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_transcript').setLabel('Transcript').setStyle(ButtonStyle.Secondary)
  );
}

async function openTicket(interaction, type) {
  await interaction.deferReply({ ephemeral: true });
  await playInteractionSequence(
    interaction,
    [
      storeEmbed('Đang khởi tạo phòng hỗ trợ', `${spinner(0)} Đang chuẩn bị không gian riêng tư cho bạn...`),
      storeEmbed('Đang khởi tạo phòng hỗ trợ', `${spinner(1)} Đang thiết lập quyền truy cập và mời đội ngũ hỗ trợ vào phòng...`),
    ],
    { delay: 420 }
  );

  const { channel, ticket, reused } = await ticketService.createTicketChannel(interaction.guild, interaction.user, type);

  if (!reused) {
    const embed = storeEmbed(
      `Ticket — ${TYPE_DISPLAY[type] || 'Khác'}`,
      [
        `Xin chào <@${interaction.user.id}>, cảm ơn bạn đã liên hệ ${config.store.name}. Đây là không gian riêng chỉ giữa bạn và đội ngũ hỗ trợ — hãy mô tả rõ nhu cầu của bạn để chúng tôi xử lý nhanh nhất có thể.`,
        DIVIDER,
      ].join('\n')
    ).addFields(
      { name: 'Loại yêu cầu', value: TYPE_DISPLAY[type] || 'Khác', inline: true },
      { name: 'Người tạo', value: `<@${interaction.user.id}>`, inline: true },
      { name: 'Thời gian', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
    );
    await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [buildTicketControlRow()] });
    await sendChannelLog(
      interaction.client,
      config.channels.ticketLog,
      storeEmbed('Ticket Created', `Kênh: <#${channel.id}>\nNgười tạo: <@${interaction.user.id}>\nLoại: ${TYPE_DISPLAY[type] || type}`)
    );
  }

  await interaction.editReply({ embeds: [successEmbed('Phòng hỗ trợ đã sẵn sàng', `Ticket của bạn: <#${channel.id}>`)] });
}

async function handleTicketButton(interaction) {
  const id = interaction.customId;

  if (id.startsWith('ticket_open_')) {
    const type = id.replace('ticket_open_', '');
    return openTicket(interaction, type);
  }

  const ticket = await ticketService.getTicketByChannel(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({ embeds: [errorEmbed('NOT_A_TICKET', 'Kênh này không phải là ticket.')], ephemeral: true });
  }

  if (id === 'ticket_claim') {
    if (!isStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ Staff mới có thể claim ticket.')], ephemeral: true });
    }
    await ticketService.claimTicket(interaction.channel.id, interaction.user.id);
    return interaction.reply({ embeds: [successEmbed('Đã tiếp nhận', `<@${interaction.user.id}> sẽ trực tiếp đồng hành cùng bạn trong ticket này.`)] });
  }

  if (id === 'ticket_add' || id === 'ticket_remove') {
    if (!isStaff(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ Staff mới có thể thao tác này.')], ephemeral: true });
    }
    const modal = new ModalBuilder()
      .setCustomId(id === 'ticket_add' ? 'ticket_add_modal' : 'ticket_remove_modal')
      .setTitle(id === 'ticket_add' ? 'Thêm người dùng vào ticket' : 'Xóa người dùng khỏi ticket');
    const input = new TextInputBuilder()
      .setCustomId('userId')
      .setLabel('User ID Discord')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (id === 'ticket_close') {
    if (!isStaff(interaction.member) && ticket.userId !== interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Bạn không có quyền đóng ticket này.')], ephemeral: true });
    }

    await interaction.deferReply();
    await playInteractionSequence(
      interaction,
      [
        warningEmbed('Đang đóng ticket', `${spinner(0)} Đang lưu lại toàn bộ nội dung trao đổi thành transcript...`),
        warningEmbed('Đang đóng ticket', `${spinner(1)} Sắp hoàn tất, phòng sẽ đóng lại trong giây lát...`),
      ],
      { delay: 500 }
    );

    const transcript = await ticketService.buildTranscript(interaction.channel);
    await ticketService.closeTicket(interaction.channel.id, interaction.user.id);

    const attachment = new AttachmentBuilder(Buffer.from(transcript, 'utf8'), { name: `${interaction.channel.name}.txt` });
    await sendChannelLog(
      interaction.client,
      config.channels.ticketLog,
      storeEmbed('Ticket Closed', `Kênh: ${interaction.channel.name}\nĐóng bởi: <@${interaction.user.id}>\nThời gian: <t:${Math.floor(Date.now() / 1000)}:F>`)
    );
    const logChannel = await interaction.client.channels.fetch(config.channels.ticketLog).catch(() => null);
    if (logChannel) await logChannel.send({ files: [attachment] });

    await interaction.editReply({ embeds: [successEmbed('Ticket đã đóng', 'Cảm ơn bạn đã tin tưởng và đồng hành. Phòng sẽ được dọn dẹp sau vài giây.')] });
    setTimeout(() => interaction.channel.delete().catch(() => null), 5000);
    return;
  }

  if (id === 'ticket_transcript') {
    const transcript = await ticketService.buildTranscript(interaction.channel);
    const attachment = new AttachmentBuilder(Buffer.from(transcript, 'utf8'), { name: `${interaction.channel.name}.txt` });
    return interaction.reply({ files: [attachment], ephemeral: true });
  }
}

async function handleTicketModal(interaction) {
  const ticket = await ticketService.getTicketByChannel(interaction.channel.id);
  if (!ticket) return interaction.reply({ embeds: [errorEmbed('NOT_A_TICKET', 'Kênh này không phải là ticket.')], ephemeral: true });

  const userId = interaction.fields.getTextInputValue('userId').trim();
  if (interaction.customId === 'ticket_add_modal') {
    await ticketService.addUserToTicket(interaction.channel, userId);
    return interaction.reply({ embeds: [successEmbed('Đã thêm', `<@${userId}> đã được thêm vào ticket.`)] });
  }
  if (interaction.customId === 'ticket_remove_modal') {
    await ticketService.removeUserFromTicket(interaction.channel, userId);
    return interaction.reply({ embeds: [successEmbed('Đã xóa', `<@${userId}> đã bị xóa khỏi ticket.`)] });
  }
}

module.exports = { buildTicketControlRow, handleTicketButton, handleTicketModal, openTicket, TYPE_DISPLAY };
