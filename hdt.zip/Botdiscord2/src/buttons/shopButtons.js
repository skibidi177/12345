// src/buttons/shopButtons.js
const productService = require('../services/productService');
const orderService = require('../services/orderService');
const { storeEmbed, errorEmbed, successEmbed, DIVIDER } = require('../utils/embeds');
const { formatVND } = require('../utils/currency');
const config = require('../config/config');
const { buildCategorySelect } = require('../selectMenus/shopMenu');
const { sendChannelLog } = require('../utils/logger');
const { spinner, playInteractionSequence } = require('../utils/animate');

async function handleShopButton(interaction, overrideId = null) {
  const id = overrideId || interaction.customId;

  if (id === 'shop_buy') {
    const row = await buildCategorySelect();
    if (!row) return interaction.reply({ embeds: [errorEmbed('NO_PRODUCTS', 'Cửa hàng hiện chưa có sản phẩm nào.')], ephemeral: true });
    return interaction.reply({
      embeds: [
        storeEmbed(
          'Mua hàng',
          'Chọn danh mục bên dưới để xem các gói đang có. Mỗi danh mục đều được cập nhật giá và tồn kho theo thời gian thực.'
        ),
      ],
      components: [row],
      ephemeral: true,
    });
  }

  if (id === 'shop_products') {
    const products = await productService.listProducts(null);
    if (!products.length) return interaction.reply({ embeds: [errorEmbed('NO_PRODUCTS', 'Cửa hàng hiện chưa có sản phẩm nào.')], ephemeral: true });

    const grouped = {};
    for (const p of products) {
      grouped[p.category] = grouped[p.category] || [];
      grouped[p.category].push(
        `${p.name}${p.packageLabel ? ' — ' + p.packageLabel : ''}\n**${formatVND(p.price)}**  ·  ${p.stock > 0 ? `còn ${p.stock}` : 'HẾT HÀNG'}`
      );
    }

    const embed = storeEmbed('Bảng giá sản phẩm', `Toàn bộ danh mục đang mở bán tại ${config.store.name}.\n${DIVIDER}`).addFields(
      Object.entries(grouped).map(([category, lines]) => ({
        name: category,
        value: lines.join('\n\n').slice(0, 1024),
        inline: true,
      }))
    );

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (id === 'shop_deposit') {
    return interaction.reply({
      embeds: [storeEmbed('Nạp tiền', 'Vui lòng sử dụng lệnh `-deposit <số tiền>` để hệ thống tạo mã QR nạp tiền dành riêng cho bạn.')],
      ephemeral: true,
    });
  }

  if (id === 'shop_ticket') {
    return interaction.reply({
      embeds: [storeEmbed('Ticket', 'Vui lòng sử dụng lệnh `-ticket` để mở một phòng riêng tư, nơi đội ngũ hỗ trợ sẽ đồng hành cùng bạn.')],
      ephemeral: true,
    });
  }

  if (id === 'shop_history') {
    const orders = await orderService.listOrdersByUser(interaction.user.id, 10);
    if (!orders.length) return interaction.reply({ embeds: [storeEmbed('Lịch sử đơn hàng', 'Bạn chưa có đơn hàng nào. Hãy bắt đầu với mục Mua hàng.')], ephemeral: true });
    const lines = orders.map((o) => `\`${o.orderId}\`  ${o.productName}  —  **${formatVND(o.price)}**  —  ${o.status}`);
    return interaction.reply({ embeds: [storeEmbed('Lịch sử đơn hàng (10 gần nhất)', lines.join('\n'))], ephemeral: true });
  }

  if (id === 'shop_account') {
    return interaction.reply({ embeds: [storeEmbed('Tài khoản', 'Vui lòng sử dụng lệnh `-profile` để xem hồ sơ, số dư và hạng thành viên của bạn.')], ephemeral: true });
  }

  if (id === 'shop_guide') {
    const embed = storeEmbed(
      'Hướng dẫn mua hàng',
      `Một giao dịch trọn vẹn tại ${config.store.name} chỉ mất vài phút. Làm theo các bước dưới đây để mọi thứ diễn ra suôn sẻ.`
    ).addFields(
      { name: 'Bước 1 — Chọn sản phẩm', value: 'Bấm **Mua hàng**, chọn danh mục và gói phù hợp với nhu cầu của bạn.' },
      { name: 'Bước 2 — Tạo đơn hàng', value: 'Bấm **Mua ngay** để hệ thống tạo mã đơn hàng riêng cho bạn.' },
      { name: 'Bước 3 — Mở phòng thanh toán', value: 'Mở ticket, đội ngũ Staff sẽ tạo mã thanh toán VietQR ngay trong phòng.' },
      { name: 'Bước 4 — Chuyển khoản', value: 'Quét mã, chuyển đúng số tiền và đúng nội dung chuyển khoản được cung cấp.' },
      { name: 'Bước 5 — Xác nhận', value: 'Chạy `-qrdone` và gửi ảnh bill để hệ thống bắt đầu đối soát tự động.' },
      { name: 'Bước 6 — Nhận hàng', value: 'Sau khi thanh toán được xác nhận, Staff sẽ bàn giao sản phẩm ngay trong ticket.' }
    );
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (id.startsWith('buy_now:')) {
    const productId = id.split(':')[1];
    const product = await productService.getProduct(productId);
    if (!product || !product.active || product.stock <= 0) {
      return interaction.reply({ embeds: [errorEmbed('PRODUCT_UNAVAILABLE', 'Sản phẩm này hiện không khả dụng hoặc đã hết hàng.')], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    await playInteractionSequence(
      interaction,
      [storeEmbed('Đang tạo đơn hàng', `${spinner(0)} Đang giữ chỗ sản phẩm và khởi tạo mã đơn hàng của bạn...`)],
      { delay: 300 }
    );

    const order = await orderService.createOrder({ userId: interaction.user.id, product });
    await productService.decrementStockAndIncrementSold(productId);

    await sendChannelLog(
      interaction.client,
      config.channels.orderLog,
      storeEmbed('Order Created', `Order: \`${order.orderId}\`\nKhách: <@${interaction.user.id}>\nSản phẩm: ${order.productName}\nGiá: ${formatVND(order.price)}`)
    );

    const embed = successEmbed('Đơn hàng đã được tạo', `Chỉ còn một bước nữa là sản phẩm sẽ về tay bạn.`).addFields(
      { name: 'Mã đơn hàng', value: `\`${order.orderId}\``, inline: true },
      { name: 'Sản phẩm', value: `**${order.productName}**`, inline: true },
      { name: 'Giá', value: `**${formatVND(order.price)}**`, inline: true },
      { name: 'Bước tiếp theo', value: 'Mở ticket (`-ticket`) để đội ngũ Staff hỗ trợ tạo mã thanh toán cho đơn này.' }
    );

    return interaction.editReply({ embeds: [embed] });
  }
}

module.exports = { handleShopButton };
