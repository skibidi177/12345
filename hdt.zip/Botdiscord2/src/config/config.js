// src/config/config.js
require('dotenv').config();

function parseIdList(value) {
  return (value || '')
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean);
}

const config = {
  discord: {
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
    guildId: process.env.GUILD_ID,
    ownerId: process.env.OWNER_ID,
  },
  database: {
    uri: process.env.MONGODB_URI,
  },
  roles: {
    admin: process.env.ADMIN_ROLE_ID,
    manager: process.env.MANAGER_ROLE_ID,
    staff: process.env.STAFF_ROLE_ID,
    support: process.env.SUPPORT_ROLE_ID,
    customer: process.env.CUSTOMER_ROLE_ID,
    paymentStaff: parseIdList(process.env.PAYMENT_STAFF_ROLE_IDS),
  },
  channels: {
    orderLog: process.env.ORDER_LOG_CHANNEL_ID,
    paymentLog: process.env.PAYMENT_LOG_CHANNEL_ID,
    ticketLog: process.env.TICKET_LOG_CHANNEL_ID,
    adminLog: process.env.ADMIN_LOG_CHANNEL_ID,
    securityLog: process.env.SECURITY_LOG_CHANNEL_ID,
    accountStaff: process.env.ACCOUNT_STAFF_CHANNEL_ID,
    welcome: process.env.WELCOME_CHANNEL_ID,
    review: process.env.REVIEW_CHANNEL_ID,
  },
  ticket: {
    categoryId: process.env.TICKET_CATEGORY_ID,
  },
  store: {
    name: process.env.STORE_NAME || 'HDT STORE',
    color: process.env.STORE_COLOR || '#2b2d31',
    tagline: process.env.STORE_TAGLINE || 'Uy tín tạo nên thương hiệu',
    bannerUrl: process.env.STORE_BANNER_URL || null,
    thumbnailUrl: process.env.STORE_THUMBNAIL_URL || null,
  },
  vietqr: {
    clientId: process.env.VIETQR_CLIENT_ID,
    apiKey: process.env.VIETQR_API_KEY,
    bankBin: process.env.PAYMENT_BANK_BIN,
    bankName: process.env.PAYMENT_BANK_NAME,
    accountNumber: process.env.PAYMENT_ACCOUNT_NUMBER,
    accountName: process.env.PAYMENT_ACCOUNT_NAME,
    transferPrefix: process.env.PAYMENT_TRANSFER_PREFIX || 'HDT',
    expirationMinutes: parseInt(process.env.PAYMENT_EXPIRATION_MINUTES || '15', 10),
    template: process.env.QR_TEMPLATE || 'compact2',
  },
  security: {
    encryptionKey: process.env.ENCRYPTION_KEY,
    webhookSecret: process.env.WEBHOOK_SECRET,
    webhookPort: parseInt(process.env.WEBHOOK_PORT || '3001', 10),
  },
  loyalty: {
    bronze: 0,
    silver: 500000,
    gold: 2000000,
    diamond: 10000000,
  },
};

module.exports = config;
