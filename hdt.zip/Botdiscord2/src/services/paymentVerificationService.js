// src/services/paymentVerificationService.js
// The ONLY module allowed to decide a PaymentRequest is actually PAID.
// Matching is strict and reconciled against real transaction data - never
// against a customer's claim, a screenshot, or a staff member's say-so.
const config = require('../config/config');
const PaymentRequest = require('../models/PaymentRequest');
const Transaction = require('../models/Transaction');
const Order = require('../models/Order');
const { transferContentMatches } = require('../utils/transferNormalizer');

const MatchResult = {
  MATCHED: 'MATCHED',
  AMOUNT_MISMATCH: 'AMOUNT_MISMATCH',
  CONTENT_MISMATCH: 'CONTENT_MISMATCH',
  DESTINATION_MISMATCH: 'DESTINATION_MISMATCH',
  TRANSACTION_ALREADY_USED: 'TRANSACTION_ALREADY_USED',
  TRANSACTION_NOT_FOUND: 'TRANSACTION_NOT_FOUND',
  PAYMENT_EXPIRED: 'PAYMENT_EXPIRED',
};

function evaluateMatch(paymentRequest, transaction) {
  if (transaction.used) {
    return MatchResult.TRANSACTION_ALREADY_USED;
  }
  if (paymentRequest.expiresAt && paymentRequest.expiresAt.getTime() < transaction.transactionTime.getTime()) {
    return MatchResult.PAYMENT_EXPIRED;
  }
  if (transaction.transactionTime.getTime() < paymentRequest.createdAt.getTime() - 2 * 60 * 1000) {
    // allow a small negative clock-skew tolerance, otherwise reject stale/replayed txns
    return MatchResult.TRANSACTION_NOT_FOUND;
  }
  if (
    transaction.accountNumber &&
    config.vietqr.accountNumber &&
    transaction.accountNumber !== config.vietqr.accountNumber
  ) {
    return MatchResult.DESTINATION_MISMATCH;
  }
  if (!transferContentMatches(paymentRequest.transferContent, transaction.description)) {
    return MatchResult.CONTENT_MISMATCH;
  }
  if (transaction.amount !== paymentRequest.amount) {
    return MatchResult.AMOUNT_MISMATCH;
  }
  return MatchResult.MATCHED;
}

// Looks through unused transactions received after this payment was created
// for one that matches. Returns { result, transaction }.
async function findMatchingTransaction(paymentRequest) {
  if (paymentRequest.status !== 'PENDING') {
    return { result: null, transaction: null };
  }
  if (paymentRequest.expiresAt.getTime() < Date.now()) {
    return { result: MatchResult.PAYMENT_EXPIRED, transaction: null };
  }

  const candidates = await Transaction.find({
    used: false,
    amount: paymentRequest.amount,
  }).sort({ transactionTime: 1 });

  for (const tx of candidates) {
    const result = evaluateMatch(paymentRequest, tx);
    if (result === MatchResult.MATCHED) {
      return { result, transaction: tx };
    }
  }

  // Nothing matched on amount+content - check if there's an amount match with
  // wrong content, or right content with wrong amount, purely for staff visibility.
  const contentOnly = await Transaction.findOne({
    used: false,
    description: { $regex: paymentRequest.transferContent, $options: 'i' },
  });
  if (contentOnly) {
    return { result: evaluateMatch(paymentRequest, contentOnly), transaction: contentOnly };
  }

  return { result: MatchResult.TRANSACTION_NOT_FOUND, transaction: null };
}

// Applies a MATCHED result: marks PaymentRequest PAID, Transaction used, and
// (for ORDER-kind payments) moves the Order to PAID.
async function confirmPayment(paymentRequest, transaction) {
  transaction.used = true;
  transaction.usedByPaymentId = paymentRequest.paymentId;
  await transaction.save();

  paymentRequest.status = 'PAID';
  paymentRequest.paidAt = new Date();
  paymentRequest.transactionReference = transaction.reference;
  await paymentRequest.save();

  if (paymentRequest.kind === 'ORDER' && paymentRequest.orderId) {
    await Order.findOneAndUpdate(
      { orderId: paymentRequest.orderId },
      { $set: { status: 'PAID' } }
    );
  }

  return paymentRequest;
}

async function recordIncomingTransaction({ reference, amount, description, accountNumber, transactionTime, rawPayload }) {
  const existing = await Transaction.findOne({ reference });
  if (existing) return existing;
  return Transaction.create({
    reference,
    amount,
    description,
    accountNumber,
    transactionTime: transactionTime ? new Date(transactionTime) : new Date(),
    rawPayload: rawPayload || {},
  });
}

module.exports = {
  MatchResult,
  evaluateMatch,
  findMatchingTransaction,
  confirmPayment,
  recordIncomingTransaction,
};
