// src/services/statsService.js
const Order = require('../models/Order');

function startOfDay() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
function startOfWeek() {
  const d = startOfDay();
  const day = d.getDay() || 7;
  d.setDate(d.getDate() - day + 1);
  return d;
}
function startOfMonth() {
  const d = startOfDay();
  d.setDate(1);
  return d;
}

async function revenueSince(date) {
  const result = await Order.aggregate([
    { $match: { status: { $in: ['PAID', 'PROCESSING', 'COMPLETED'] }, createdAt: { $gte: date } } },
    { $group: { _id: null, total: { $sum: '$price' }, count: { $sum: 1 } } },
  ]);
  return result[0] || { total: 0, count: 0 };
}

async function overview() {
  const [today, week, month, allTime, completed, cancelled, topProducts, topCustomers] = await Promise.all([
    revenueSince(startOfDay()),
    revenueSince(startOfWeek()),
    revenueSince(startOfMonth()),
    revenueSince(new Date(0)),
    Order.countDocuments({ status: 'COMPLETED' }),
    Order.countDocuments({ status: 'CANCELLED' }),
    Order.aggregate([
      { $match: { status: { $in: ['PAID', 'PROCESSING', 'COMPLETED'] } } },
      { $group: { _id: '$productName', count: { $sum: 1 }, revenue: { $sum: '$price' } } },
      { $sort: { count: -1 } },
      { $limit: 5 },
    ]),
    Order.aggregate([
      { $match: { status: { $in: ['PAID', 'PROCESSING', 'COMPLETED'] } } },
      { $group: { _id: '$userId', total: { $sum: '$price' } } },
      { $sort: { total: -1 } },
      { $limit: 5 },
    ]),
  ]);

  return { today, week, month, allTime, completed, cancelled, topProducts, topCustomers };
}

module.exports = { overview };
