// src/services/productService.js
const Product = require('../models/Product');

async function listCategories() {
  return Product.distinct('category');
}

async function listProducts(category, { onlyActive = true } = {}) {
  const filter = {};
  if (category) filter.category = category;
  if (onlyActive) filter.active = true;
  return Product.find(filter).sort({ category: 1, price: 1 });
}

async function getProduct(productId) {
  return Product.findOne({ productId });
}

async function createProduct(data) {
  return Product.create(data);
}

async function removeProduct(productId) {
  return Product.findOneAndDelete({ productId });
}

async function editProduct(productId, updates) {
  return Product.findOneAndUpdate({ productId }, { $set: updates }, { new: true });
}

async function setPrice(productId, price) {
  return Product.findOneAndUpdate({ productId }, { $set: { price } }, { new: true });
}

async function setStock(productId, stock) {
  return Product.findOneAndUpdate({ productId }, { $set: { stock } }, { new: true });
}

async function addStock(productId, amount) {
  return Product.findOneAndUpdate({ productId }, { $inc: { stock: amount } }, { new: true });
}

async function toggleActive(productId) {
  const product = await Product.findOne({ productId });
  if (!product) return null;
  product.active = !product.active;
  await product.save();
  return product;
}

async function decrementStockAndIncrementSold(productId) {
  return Product.findOneAndUpdate(
    { productId, stock: { $gt: 0 } },
    { $inc: { stock: -1, sold: 1 } },
    { new: true }
  );
}

module.exports = {
  listCategories,
  listProducts,
  getProduct,
  createProduct,
  removeProduct,
  editProduct,
  setPrice,
  setStock,
  addStock,
  toggleActive,
  decrementStockAndIncrementSold,
};
