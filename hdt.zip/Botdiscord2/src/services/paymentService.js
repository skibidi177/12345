// src/services/paymentService.js
// Owns the PaymentRequest lifecycle (create / cancel / expire). Does NOT
// decide whether a payment is actually paid - that is paymentVerificationService's
// job exclusively, so "creating a QR" can never be confused with "money received".
const config = require('../config/config');
const PaymentRequest = require('../models/PaymentRequest');
const { generateUniqueTransferContent } = require('../utils/paymentCode');
const { generatePaymentId } = require('../utils/orderId');
const { generateQuickLinkQR } = require('./vietqrService');

async function getPendingForTicket(ticketId) {
  return PaymentRequest.findOne({ ticketId, status: 'PENDING' });
}

async function createPayment({ kind = 'ORDER', orderId = null, ticketId, customerId, createdBy, amount }) {
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error('INVALID_AMOUNT');
  }

  const transferContent = await generateUniqueTransferContent();
  const paymentId = await generatePaymentId();
  const expiresAt = new Date(Date.now() + config.vietqr.expirationMinutes * 60 * 1000);

  const qrDataURL = await generateQuickLinkQR({ amount, addInfo: transferContent });

  const payment = await PaymentRequest.create({
    paymentId,
    kind,
    orderId,
    ticketId,
    customerId,
    createdBy,
    amount,
    transferContent,
    status: 'PENDING',
    qrDataURL,
    expiresAt,
  });

  return payment;
}

async function getPayment(paymentId) {
  return PaymentRequest.findOne({ paymentId });
}

async function cancelPayment(paymentId) {
  return PaymentRequest.findOneAndUpdate(
    { paymentId, status: 'PENDING' },
    { $set: { status: 'CANCELLED' } },
    { new: true }
  );
}

async function expireDuePayments() {
  const now = new Date();
  const result = await PaymentRequest.updateMany(
    { status: 'PENDING', expiresAt: { $lte: now } },
    { $set: { status: 'EXPIRED' } }
  );
  return result.modifiedCount || 0;
}

async function listPending(limit = 25) {
  return PaymentRequest.find({ status: 'PENDING' }).sort({ createdAt: -1 }).limit(limit);
}

async function searchByOrder(orderId) {
  return PaymentRequest.find({ orderId }).sort({ createdAt: -1 });
}

async function touchLastChecked(paymentId) {
  return PaymentRequest.findOneAndUpdate({ paymentId }, { $set: { lastCheckedAt: new Date() } });
}

module.exports = {
  getPendingForTicket,
  createPayment,
  getPayment,
  cancelPayment,
  expireDuePayments,
  listPending,
  searchByOrder,
  touchLastChecked,
};
