// src/services/ticketService.js
const { ChannelType, PermissionsBitField } = require('discord.js');
const config = require('../config/config');
const Ticket = require('../models/Ticket');

const TYPE_LABELS = {
  MUA_HANG: 'mua-hang',
  HO_TRO: 'ho-tro',
  THANH_TOAN: 'thanh-toan',
  BAO_HANH: 'bao-hanh',
  KHAC: 'khac',
};

async function createTicketChannel(guild, user, type = 'KHAC') {
  const existing = await Ticket.findOne({ userId: user.id, status: 'OPEN', type });
  if (existing) {
    const channel = await guild.channels.fetch(existing.channelId).catch(() => null);
    if (channel) return { channel, ticket: existing, reused: true };
  }

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
    {
      id: user.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
        PermissionsBitField.Flags.AttachFiles,
      ],
    },
    {
      id: guild.members.me.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.ManageMessages,
      ],
    },
  ];

  for (const roleId of [config.roles.staff, config.roles.support, config.roles.admin, config.roles.manager]) {
    if (roleId) {
      overwrites.push({
        id: roleId,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
        ],
      });
    }
  }

  const channel = await guild.channels.create({
    name: `${TYPE_LABELS[type] || 'ticket'}-${user.username}`.slice(0, 90),
    type: ChannelType.GuildText,
    parent: config.ticket.categoryId || undefined,
    permissionOverwrites: overwrites,
  });

  const ticket = await Ticket.create({
    channelId: channel.id,
    guildId: guild.id,
    type,
    userId: user.id,
  });

  return { channel, ticket, reused: false };
}

async function getTicketByChannel(channelId) {
  return Ticket.findOne({ channelId });
}

async function claimTicket(channelId, staffId) {
  return Ticket.findOneAndUpdate({ channelId }, { $set: { claimedBy: staffId } }, { new: true });
}

async function addUserToTicket(channel, userId) {
  await channel.permissionOverwrites.edit(userId, {
    ViewChannel: true,
    SendMessages: true,
    ReadMessageHistory: true,
  });
}

async function removeUserFromTicket(channel, userId) {
  await channel.permissionOverwrites.delete(userId).catch(() => null);
}

async function attachOrder(channelId, orderId) {
  return Ticket.findOneAndUpdate({ channelId }, { $set: { orderId } }, { new: true });
}

async function closeTicket(channelId, closedBy, reason = null) {
  return Ticket.findOneAndUpdate(
    { channelId },
    { $set: { status: 'CLOSED', closedBy, closedAt: new Date(), closeReason: reason } },
    { new: true }
  );
}

async function buildTranscript(channel, limit = 500) {
  const messages = await channel.messages.fetch({ limit: Math.min(limit, 100) });
  const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  const lines = sorted.map((m) => {
    const time = new Date(m.createdTimestamp).toISOString();
    const content = m.content || '[embed/attachment]';
    return `[${time}] ${m.author.tag} (${m.author.id}): ${content}`;
  });
  return lines.join('\n');
}

module.exports = {
  createTicketChannel,
  getTicketByChannel,
  claimTicket,
  addUserToTicket,
  removeUserFromTicket,
  attachOrder,
  closeTicket,
  buildTranscript,
  TYPE_LABELS,
};
