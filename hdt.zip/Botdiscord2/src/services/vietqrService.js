// src/services/vietqrService.js
// Talks to the VietQR "generate" API ONLY. This module is purely about
// producing a QR image - it has no knowledge of whether money has actually
// moved. See paymentVerificationService for that half of the system.
const axios = require('axios');
const config = require('../config/config');

async function generateQuickLinkQR({ amount, addInfo }) {
  const { clientId, apiKey, bankBin, accountNumber, accountName, template } = config.vietqr;

  if (!clientId || !apiKey || !bankBin || !accountNumber || !accountName) {
    throw new Error('VIETQR_CONFIG_MISSING');
  }

  const response = await axios.post(
    'https://api.vietqr.io/v2/generate',
    {
      accountNo: accountNumber,
      accountName,
      acqId: bankBin,
      amount,
      addInfo,
      template,
    },
    {
      headers: {
        'x-client-id': clientId,
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      timeout: 10000,
    }
  );

  const data = response.data;
  if (!data || data.code !== '00' || !data.data || !data.data.qrDataURL) {
    throw new Error('VIETQR_GENERATE_FAILED');
  }

  return data.data.qrDataURL; // base64 data URI
}

module.exports = { generateQuickLinkQR };
