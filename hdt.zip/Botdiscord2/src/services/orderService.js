// src/services/orderService.js
const Order = require('../models/Order');
const User = require('../models/User');
const { generateOrderId } = require('../utils/orderId');

async function ensureUser(discordId) {
  let user = await User.findOne({ discordId });
  if (!user) user = await User.create({ discordId });
  return user;
}

async function createOrder({ userId, product }) {
  await ensureUser(userId);
  const orderId = await generateOrderId();
  const order = await Order.create({
    orderId,
    userId,
    productId: product.productId,
    productName: `${product.category} - ${product.name}`,
    packageLabel: product.packageLabel,
    price: product.price,
    status: 'WAITING_PAYMENT',
    warrantyDays: product.warrantyDays,
  });
  await User.updateOne({ discordId: userId }, { $inc: { totalOrders: 1 } });
  return order;
}

async function getOrder(orderId) {
  return Order.findOne({ orderId });
}

async function getOrderByTicket(channelId) {
  return Order.findOne({ ticketId: channelId }).sort({ createdAt: -1 });
}

async function attachTicket(orderId, channelId) {
  return Order.findOneAndUpdate({ orderId }, { $set: { ticketId: channelId } }, { new: true });
}

async function updateStatus(orderId, status, staffId = null) {
  const update = { status };
  if (staffId) update.staffId = staffId;
  if (status === 'COMPLETED') {
    update.completedAt = new Date();
  }
  const order = await Order.findOneAndUpdate({ orderId }, { $set: update }, { new: true });
  if (order && status === 'PAID') {
    const warrantyExpiresAt = new Date(Date.now() + order.warrantyDays * 24 * 60 * 60 * 1000);
    order.warrantyExpiresAt = warrantyExpiresAt;
    await order.save();
  }
  if (order && status === 'COMPLETED') {
    await User.updateOne(
      { discordId: order.userId },
      { $inc: { completedOrders: 1, totalSpent: order.price } }
    );
  }
  return order;
}

async function listOrdersByUser(userId, limit = 10) {
  return Order.find({ userId }).sort({ createdAt: -1 }).limit(limit);
}

async function listOrdersByStatus(status, limit = 25) {
  const filter = status ? { status } : {};
  return Order.find(filter).sort({ createdAt: -1 }).limit(limit);
}

module.exports = {
  ensureUser,
  createOrder,
  getOrder,
  getOrderByTicket,
  attachTicket,
  updateStatus,
  listOrdersByUser,
  listOrdersByStatus,
};
