// src/web/server.js
// Receives payment confirmation webhooks (VietQR Payment Kit / Open Banking
// provider) and reconciles them against PaymentRequests. This is the
// preferred confirmation path; the in-Discord "Kiểm tra thanh toán" button
// and the /qrdone auto-check loop are fallbacks for when no webhook arrives.
const express = require('express');
const config = require('../config/config');
const paymentService = require('../services/paymentService');
const paymentVerificationService = require('../services/paymentVerificationService');
const { storeEmbed, successEmbed } = require('../utils/embeds');
const { formatVND } = require('../utils/currency');
const { sendChannelLog } = require('../utils/logger');

function startWebhookServer(client) {
  const app = express();
  app.use(express.json());

  app.post('/webhooks/vietqr', async (req, res) => {
    const secret = req.headers['x-webhook-secret'];
    if (!config.security.webhookSecret || secret !== config.security.webhookSecret) {
      return res.status(401).json({ ok: false, error: 'UNAUTHORIZED' });
    }

    try {
      const { reference, amount, description, accountNumber, transactionDatetime } = req.body || {};
      if (!reference || !amount || !description) {
        return res.status(400).json({ ok: false, error: 'INVALID_PAYLOAD' });
      }

      const transaction = await paymentVerificationService.recordIncomingTransaction({
        reference,
        amount: Number(amount),
        description: String(description),
        accountNumber: accountNumber || null,
        transactionTime: transactionDatetime,
        rawPayload: req.body,
      });

      // Try to match against any still-pending payment requests.
      const PaymentRequest = require('../models/PaymentRequest');
      const pendingList = await PaymentRequest.find({ status: 'PENDING', amount: transaction.amount });

      for (const payment of pendingList) {
        const result = paymentVerificationService.evaluateMatch(payment, transaction);
        if (result === paymentVerificationService.MatchResult.MATCHED) {
          await paymentVerificationService.confirmPayment(payment, transaction);

          await sendChannelLog(
            client,
            config.channels.paymentLog,
            storeEmbed('Payment Confirmed (Webhook)', `Payment ID: \`${payment.paymentId}\`\n${payment.orderId ? `Order ID: \`${payment.orderId}\`\n` : ''}Amount: **${formatVND(payment.amount)}**\nReference: \`${reference}\``)
          );

          if (payment.ticketId) {
            const channel = await client.channels.fetch(payment.ticketId).catch(() => null);
            if (channel) {
              await channel.send({
                embeds: [
                  successEmbed(
                    'PAYMENT SUCCESS',
                    `Thanh toán đã được xác nhận.\n\nOrder: \`${payment.orderId || '-'}\`\nAmount: **${formatVND(payment.amount)}**\nPayment: **PAID**\nTransaction: \`${reference}\``
                  ),
                ],
              });
            }
          }

          return res.json({ ok: true, matched: true, paymentId: payment.paymentId });
        }
      }

      return res.json({ ok: true, matched: false });
    } catch (err) {
      console.error('[WEBHOOK]', err.message);
      return res.status(500).json({ ok: false, error: 'INTERNAL_ERROR' });
    }
  });

  app.listen(config.security.webhookPort, () => {
    console.log(`[WEBHOOK] Listening on port ${config.security.webhookPort}`);
  });
}

module.exports = { startWebhookServer };
