// src/database/connect.js
const mongoose = require('mongoose');
const config = require('../config/config');

async function connectDatabase() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(config.database.uri);
  console.log('[DATABASE] Connected to MongoDB.');

  mongoose.connection.on('error', (err) => {
    console.error('[DATABASE] Connection error:', err.message);
  });
  mongoose.connection.on('disconnected', () => {
    console.warn('[DATABASE] Disconnected from MongoDB.');
  });
}

module.exports = { connectDatabase };
