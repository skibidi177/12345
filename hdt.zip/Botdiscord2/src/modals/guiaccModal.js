// src/modals/guiaccModal.js
// OWNER-only secure account delivery intake (spec section 6). Credentials are
// NEVER posted to a public channel, never logged, and the password is
// encrypted at rest until a Staff member marks the request processed.
const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config/config');
const AccountRequest = require('../models/AccountRequest');
const { generateAccountRequestId } = require('../utils/orderId');
const { encrypt } = require('../utils/crypto');
const { storeEmbed, errorEmbed } = require('../utils/embeds');
const { sendChannelLog, logSecurityEvent } = require('../utils/logger');
const { buildAccountRequestRow } = require('../buttons/accountButtons');

function buildGuiAccModal() {
  const modal = new ModalBuilder().setCustomId('guiacc_modal').setTitle('Bàn giao tài khoản (OWNER ONLY)');

  const productType = new TextInputBuilder()
    .setCustomId('productType')
    .setLabel('Loại sản phẩm')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
  const account = new TextInputBuilder()
    .setCustomId('account')
    .setLabel('Email/Tài khoản')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
  const password = new TextInputBuilder()
    .setCustomId('password')
    .setLabel('Mật khẩu')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
  const note = new TextInputBuilder()
    .setCustomId('note')
    .setLabel('Ghi chú')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);
  const orderId = new TextInputBuilder()
    .setCustomId('orderId')
    .setLabel('Order ID liên quan (nếu có)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(productType),
    new ActionRowBuilder().addComponents(account),
    new ActionRowBuilder().addComponents(password),
    new ActionRowBuilder().addComponents(note),
    new ActionRowBuilder().addComponents(orderId)
  );
  return modal;
}

async function handleGuiAccSubmit(interaction) {
  if (interaction.user.id !== config.discord.ownerId) {
    // Should be unreachable since /guiacc itself is owner-gated, but never trust the UI alone.
    await logSecurityEvent('GUIACC_UNAUTHORIZED_MODAL_SUBMIT', interaction.user.id, 'Modal submit blocked');
    return interaction.reply({ embeds: [errorEmbed('FORBIDDEN', 'Chỉ OWNER được sử dụng chức năng này.')], ephemeral: true });
  }

  const productType = interaction.fields.getTextInputValue('productType');
  const account = interaction.fields.getTextInputValue('account');
  const password = interaction.fields.getTextInputValue('password');
  const note = interaction.fields.getTextInputValue('note') || '';
  const orderId = interaction.fields.getTextInputValue('orderId') || null;

  const requestId = await generateAccountRequestId();
  const passwordEnc = encrypt(password); // never store plaintext, never console.log this

  const record = await AccountRequest.create({
    requestId,
    orderId,
    ownerId: interaction.user.id,
    productType,
    account,
    note,
    passwordEnc,
    status: 'PENDING',
  });

  const embed = storeEmbed(
    'ACCOUNT DELIVERY REQUEST',
    [
      orderId ? `Order: \`${orderId}\`` : null,
      `Customer: (gắn qua ticket)`,
      `Product: **${productType}**`,
      `Account: \`${account}\``,
      `Password: ||********||`,
      note ? `Ghi chú: ${note}` : null,
      `Request ID: \`${requestId}\``,
    ]
      .filter(Boolean)
      .join('\n')
  );

  await sendChannelLog(interaction.client, config.channels.accountStaff, embed);
  const staffChannel = await interaction.client.channels.fetch(config.channels.accountStaff).catch(() => null);
  if (staffChannel) {
    await staffChannel.send({ embeds: [embed], components: [buildAccountRequestRow(requestId)] });
  }

  await logSecurityEvent('GUIACC_REQUEST_CREATED', interaction.user.id, `requestId=${requestId}`);

  await interaction.reply({
    embeds: [storeEmbed('Đã tạo yêu cầu bàn giao', `Request ID: \`${requestId}\`. Thông tin đã được gửi vào kênh bảo mật.`)],
    ephemeral: true,
  });
}

module.exports = { buildGuiAccModal, handleGuiAccSubmit };
