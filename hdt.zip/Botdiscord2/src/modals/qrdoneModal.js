// src/modals/qrdoneModal.js
// /qrdone flow (spec 56-61): confirms intent only. Amount always comes from
// the PaymentRequest itself - the customer never types an amount here.
const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config/config');
const paymentService = require('../services/paymentService');
const paymentVerificationService = require('../services/paymentVerificationService');
const { storeEmbed, errorEmbed, successEmbed, warningEmbed } = require('../utils/embeds');
const { formatVND } = require('../utils/currency');
const { sendChannelLog } = require('../utils/logger');
const { spinner, progressBar, playMessageSequence } = require('../utils/animate');

function buildQrDoneModal(paymentId) {
  const modal = new ModalBuilder().setCustomId(`qrdone_modal:${paymentId}`).setTitle('Xác nhận thanh toán');

  const refInput = new TextInputBuilder()
    .setCustomId('reference')
    .setLabel('Mã giao dịch / Reference (không bắt buộc)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false);

  const noteInput = new TextInputBuilder()
    .setCustomId('note')
    .setLabel('Ghi chú (không bắt buộc)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(refInput),
    new ActionRowBuilder().addComponents(noteInput)
  );
  return modal;
}

const VALID_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

async function handleQrDoneSubmit(interaction) {
  const paymentId = interaction.customId.split(':')[1];
  const payment = await paymentService.getPayment(paymentId);

  if (!payment || payment.status !== 'PENDING') {
    return interaction.reply({
      embeds: [errorEmbed('PAYMENT_NOT_PENDING', 'Yêu cầu thanh toán này không còn hiệu lực.')],
      ephemeral: true,
    });
  }

  await interaction.reply({
    embeds: [
      storeEmbed(
        'Đã ghi nhận',
        'Cảm ơn bạn đã báo lại. Vui lòng gửi **ảnh chụp bill chuyển khoản** vào tin nhắn tiếp theo trong ticket này (trong vòng 5 phút) để hệ thống bắt đầu đối soát.'
      ),
    ],
    ephemeral: true,
  });

  const channel = interaction.channel;
  const collector = channel.createMessageCollector({
    filter: (m) => m.author.id === interaction.user.id && m.attachments.size > 0,
    time: 5 * 60 * 1000,
    max: 1,
  });

  collector.on('collect', async (message) => {
    const attachment = message.attachments.first();
    if (!VALID_IMAGE_TYPES.includes(attachment.contentType)) {
      await channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [errorEmbed('INVALID_FILE_TYPE', 'File gửi lên không phải ảnh hợp lệ (png/jpg/webp). Vui lòng thử lại bằng /qrdone.')],
      });
      return;
    }

    const verificationEmbed = storeEmbed('PAYMENT VERIFICATION', `Khách hàng <@${interaction.user.id}> đã báo hoàn tất chuyển khoản.`).addFields(
      { name: 'Đơn hàng', value: payment.orderId ? `\`${payment.orderId}\`` : '—', inline: true },
      { name: 'Số tiền cần nhận', value: `**${formatVND(payment.amount)}**`, inline: true },
      { name: 'Nội dung chuyển khoản', value: `\`${payment.transferContent}\``, inline: true }
    ).setImage(attachment.url);

    await sendChannelLog(interaction.client, config.channels.paymentLog, verificationEmbed);

    await autoCheckLoop(interaction.client, channel, payment.paymentId, interaction.user.id);
  });

  collector.on('end', async (collected) => {
    if (collected.size === 0) {
      await channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [errorEmbed('QRDONE_TIMEOUT', 'Đã hết thời gian chờ ảnh bill. Vui lòng chạy lại /qrdone nếu bạn đã chuyển khoản.')],
      });
    }
  });
}

// Polls for a matching transaction at increasing intervals with a hard stop
// (spec 77), editing a single status message each attempt so the customer can
// watch the verification actually progress instead of staring at silence.
// Prefers webhook-driven confirmation; this loop is purely the fallback.
async function autoCheckLoop(client, channel, paymentId, customerId) {
  const delays = [0, 15000, 30000, 60000, 120000];

  const statusMessage = await channel.send({
    embeds: [
      storeEmbed('Đang xác minh giao dịch', `${spinner(0)} Hệ thống đang đối soát với ngân hàng, vui lòng chờ trong giây lát...`).addFields({
        name: 'Tiến độ',
        value: progressBar(0, delays.length),
      }),
    ],
  });

  for (let i = 0; i < delays.length; i++) {
    if (delays[i] > 0) await new Promise((resolve) => setTimeout(resolve, delays[i]));

    const payment = await paymentService.getPayment(paymentId);
    if (!payment || payment.status !== 'PENDING') return; // already resolved elsewhere (e.g. webhook)

    await statusMessage
      .edit({
        embeds: [
          storeEmbed('Đang xác minh giao dịch', `${spinner(i)} Lần kiểm tra ${i + 1}/${delays.length} — đang đối chiếu số tiền và nội dung chuyển khoản...`).addFields({
            name: 'Tiến độ',
            value: progressBar(i + 1, delays.length),
          }),
        ],
      })
      .catch(() => null);

    const { result, transaction } = await paymentVerificationService.findMatchingTransaction(payment);
    if (result === paymentVerificationService.MatchResult.MATCHED) {
      await paymentVerificationService.confirmPayment(payment, transaction);
      await statusMessage
        .edit({
          embeds: [
            successEmbed(
              'Thanh toán thành công',
              `Giao dịch của <@${customerId}> đã được xác nhận. Đội ngũ Staff sẽ bàn giao sản phẩm ngay sau đây.`
            ).addFields(
              { name: 'Đơn hàng', value: payment.orderId ? `\`${payment.orderId}\`` : '—', inline: true },
              { name: 'Số tiền', value: `**${formatVND(payment.amount)}**`, inline: true },
              { name: 'Mã giao dịch', value: `\`${transaction.reference}\``, inline: true }
            ),
          ],
        })
        .catch(() => null);
      return;
    }
  }

  await statusMessage
    .edit({
      embeds: [
        warningEmbed(
          'Chưa tìm thấy giao dịch',
          `Hệ thống chưa nhận được xác nhận tự động cho khoản thanh toán này. Staff sẽ kiểm tra thủ công — <@${customerId}> cũng có thể bấm **Kiểm tra thanh toán** trên phiếu QR sau ít phút nữa.`
        ),
      ],
    })
    .catch(() => null);
}

module.exports = { buildQrDoneModal, handleQrDoneSubmit, autoCheckLoop };
